const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";


const {
  createClient
} = supabase;


const db =
  createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =========================================================
   AUTHENTICATION GUARD
========================================================= */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await db.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


/* =========================================================
   MARKET HUB PRODUCT DETAILS
   ========================================================= */


/* =========================
   STATE
========================= */

let currentProduct = null;
let currentUser = null;

let productImages = [];
let productVariants = [];

let selectedVariants = {};
let selectedImageIndex = 0;

let availableStock = 0;

const CART_KEY =
  "marketHubCart";

let toastTimer = null;


/* =========================
   DOM ELEMENTS
========================= */

const loadingState =
  document.getElementById(
    "loadingState"
  );


const errorState =
  document.getElementById(
    "errorState"
  );


const errorMessage =
  document.getElementById(
    "errorMessage"
  );


const productContent =
  document.getElementById(
    "productContent"
  );


const mainProductImage =
  document.getElementById(
    "mainProductImage"
  );


const imageBadge =
  document.getElementById(
    "imageBadge"
  );


const saleBadge =
  document.getElementById(
    "saleBadge"
  );


const thumbnailList =
  document.getElementById(
    "thumbnailList"
  );


const productCategory =
  document.getElementById(
    "productCategory"
  );


const productName =
  document.getElementById(
    "productName"
  );


const productPrice =
  document.getElementById(
    "productPrice"
  );


const productOldPrice =
  document.getElementById(
    "productOldPrice"
  );


const productDiscount =
  document.getElementById(
    "productDiscount"
  );


const stockStatus =
  document.getElementById(
    "stockStatus"
  );


const stockNumber =
  document.getElementById(
    "stockNumber"
  );


const productDescription =
  document.getElementById(
    "productDescription"
  );


const variantsSection =
  document.getElementById(
    "variantsSection"
  );


const variantsContainer =
  document.getElementById(
    "variantsContainer"
  );


const addToCartButton =
  document.getElementById(
    "addToCartButton"
  );


const backButton =
  document.getElementById(
    "backButton"
  );


const backToShop =
  document.getElementById(
    "backToShop"
  );


const cartButton =
  document.getElementById(
    "cartButton"
  );


const cartCount =
  document.getElementById(
    "cartCount"
  );


const toast =
  document.getElementById(
    "toast"
  );


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  initializeProduct
);


async function initializeProduct() {

  /*
    Check authentication before
    allowing access to the product page.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {
    return;
  }


  setupButtons();

  updateCartCount();

  const productId =
    getProductId();


  if (!productId) {

    showError(
      "No product was selected."
    );

    return;
  }


  await loadCurrentUser();

  await loadProduct(
    productId
  );
}

/* =========================================================
   PRODUCT ID
========================================================= */

function getProductId() {

  const params =
    new URLSearchParams(
      window.location.search
    );


  return params.get(
    "id"
  );
}


/* =========================================================
   AUTH
========================================================= */

async function loadCurrentUser() {

  try {

    const {
      data,
      error
    } =
      await db.auth.getSession();


    if (error) {
      throw error;
    }


    currentUser =
      data?.session?.user ||
      null;

  } catch (error) {

    console.error(
      "AUTH SESSION ERROR:",
      error
    );

    currentUser = null;
  }
}


/* =========================================================
   LOAD PRODUCT
========================================================= */

async function loadProduct(
  productId
) {

  try {

    const {
      data: product,
      error
    } =
      await db
        .from("products")
        .select("*")
        .eq(
          "id",
          productId
        )
        .maybeSingle();


    if (error) {
      throw error;
    }


    if (!product) {

      showError(
        "This product could not be found."
      );

      return;
    }


    if (
      product.status &&
      String(
        product.status
      ).toLowerCase() !==
        "active"
    ) {

      showError(
        "This product is currently unavailable."
      );

      return;
    }


    currentProduct =
      product;


    await Promise.all([
      loadProductImages(
        productId
      ),

      loadProductVariants(
        productId
      )
    ]);


    renderProduct();

    hideLoading();

  } catch (error) {

    console.error(
      "PRODUCT LOAD ERROR:",
      error
    );


    showError(
      "We couldn't load this product. Please try again."
    );
  }
}


/* =========================================================
   LOAD IMAGES
========================================================= */

async function loadProductImages(
  productId
) {

  productImages = [];


  try {

    const {
      data,
      error
    } =
      await db
        .from("product_images")
        .select(
          "image_url, sort_order"
        )
        .eq(
          "product_id",
          productId
        )
        .order(
          "sort_order",
          {
            ascending: true,
            nullsFirst: false
          }
        );


    if (error) {
      throw error;
    }


    const databaseImages =
      (data || [])
        .map(
          item =>
            item?.image_url
        )
        .filter(Boolean);


    const jsonImages =
      extractImages(
        currentProduct?.images
      );


    productImages =
      [
        ...databaseImages,
        ...jsonImages
      ];


    productImages =
      [
        ...new Set(
          productImages
        )
      ];

  } catch (error) {

    console.error(
      "PRODUCT IMAGES ERROR:",
      error
    );


    productImages =
      extractImages(
        currentProduct?.images
      );
  }
}


/* =========================================================
   LOAD VARIANTS
========================================================= */

async function loadProductVariants(
  productId
) {

  productVariants = [];


  try {

    const {
      data,
      error
    } =
      await db
        .from("product_variants")
        .select(`
          id,
          product_id,
          variant_name,
          variant_value,
          price,
          sale_price,
          stock_quantity,
          sku,
          created_at
        `)
        .eq(
          "product_id",
          productId
        )
        .order(
          "created_at",
          {
            ascending: true
          }
        );


    if (error) {
      throw error;
    }


    productVariants =
      data || [];

  } catch (error) {

    console.error(
      "PRODUCT VARIANTS ERROR:",
      error
    );


    productVariants = [];
  }
}


/* =========================================================
   IMAGE JSON PARSER
========================================================= */

function extractImages(
  value
) {

  if (!value) {
    return [];
  }


  let images =
    value;


  if (
    typeof images ===
    "string"
  ) {

    try {

      images =
        JSON.parse(
          images
        );

    } catch {

      return images.trim()
        ? [images.trim()]
        : [];
    }
  }


  if (
    !Array.isArray(
      images
    )
  ) {

    return [];
  }


  return images
    .map(
      item => {

        if (
          typeof item ===
          "string"
        ) {

          return item;
        }


        if (
          item &&
          typeof item ===
            "object"
        ) {

          return (
            item.url ||
            item.image_url ||
            item.src ||
            ""
          );
        }


        return "";
      }
    )
    .filter(Boolean);
}


/* =========================================================
   RENDER PRODUCT
========================================================= */

function renderProduct() {

  renderBasicInfo();

  renderImages();

  renderVariants();

  renderPrice();

  renderStock();

  updateCartCount();

  updateAddToCartButton();

  productContent.style.display =
    "block";
}


/* =========================================================
   BASIC INFORMATION
========================================================= */

function renderBasicInfo() {

  productCategory.textContent =
    currentProduct.category ||
    "Product";


  productName.textContent =
    currentProduct.name ||
    "Product";


  productDescription.textContent =
    currentProduct.description ||
    "No description available.";
}


/* =========================================================
   PRICE
========================================================= */

function getBasePrice() {

  const flashSale =
    currentProduct.flash_sale === true;


  const flashPrice =
    Number(
      currentProduct.flash_price
    );


  if (
    flashSale &&
    Number.isFinite(
      flashPrice
    ) &&
    flashPrice > 0
  ) {

    return flashPrice;
  }


  const price =
    Number(
      currentProduct.price
    );


  return Number.isFinite(
    price
  )
    ? price
    : 0;
}


function getSelectedVariantRows() {

  return Object.values(
    selectedVariants
  ).filter(Boolean);
}


function getCurrentUnitPrice() {

  const basePrice =
    getBasePrice();


  const selectedRows =
    getSelectedVariantRows();


  if (
    selectedRows.length === 0
  ) {

    return basePrice;
  }


  const prices =
    selectedRows
      .map(
        row => {

          const salePrice =
            Number(
              row.sale_price
            );


          const regularPrice =
            Number(
              row.price
            );


          if (
            Number.isFinite(
              salePrice
            ) &&
            salePrice > 0
          ) {

            return salePrice;
          }


          if (
            Number.isFinite(
              regularPrice
            ) &&
            regularPrice >= 0
          ) {

            return regularPrice;
          }


          return null;
        }
      )
      .filter(
        price =>
          price !== null
      );


  if (
    prices.length ===
      selectedRows.length &&
    prices.length > 0
  ) {

    const firstPrice =
      prices[0];


    const allSame =
      prices.every(
        price =>
          price ===
          firstPrice
      );


    if (allSame) {
      return firstPrice;
    }
  }


  return basePrice;
}


function renderPrice() {

  const currentPrice =
    getCurrentUnitPrice();


  productPrice.textContent =
    formatNaira(
      currentPrice
    );


  let oldPrice =
    Number(
      currentProduct.old_price
    );


  const normalPrice =
    Number(
      currentProduct.price
    );


  if (
    currentProduct.flash_sale === true &&
    Number.isFinite(
      normalPrice
    ) &&
    normalPrice > currentPrice
  ) {

    oldPrice =
      normalPrice;
  }


  if (
    Number.isFinite(
      oldPrice
    ) &&
    oldPrice > currentPrice
  ) {

    productOldPrice.textContent =
      formatNaira(
        oldPrice
      );


    productOldPrice.style.display =
      "inline";

  } else {

    productOldPrice.style.display =
      "none";
  }


  let discount =
    Number(
      currentProduct.discount
    );


  if (
    !Number.isFinite(
      discount
    ) ||
    discount <= 0
  ) {

    if (
      Number.isFinite(
        oldPrice
      ) &&
      oldPrice > currentPrice
    ) {

      discount =
        Math.round(
          (
            (
              oldPrice -
              currentPrice
            ) /
            oldPrice
          ) * 100
        );
    }
  }


  if (
    discount > 0
  ) {

    productDiscount.textContent =
      `-${Math.round(
        discount
      )}%`;


    productDiscount.style.display =
      "inline-flex";

  } else {

    productDiscount.style.display =
      "none";
  }


  saleBadge.style.display =
    currentProduct.flash_sale === true
      ? "block"
      : "none";
}


/* =========================================================
   STOCK
========================================================= */

function getCurrentStock() {

  if (
    productVariants.length > 0
  ) {

    const selectedRows =
      getSelectedVariantRows();


    if (
      selectedRows.length > 0
    ) {

      return Math.max(
        0,
        Math.min(
          ...selectedRows.map(
            row =>
              Number(
                row.stock_quantity
              ) || 0
          )
        )
      );
    }


    const stocks =
      productVariants.map(
        row =>
          Number(
            row.stock_quantity
          ) || 0
      );


    if (
      stocks.length > 0
    ) {

      return Math.max(
        0,
        Math.min(
          ...stocks
        )
      );
    }


    return 0;
  }


  return Math.max(
    0,
    Number(
      currentProduct.stock
    ) || 0
  );
}


function renderStock() {

  availableStock =
    getCurrentStock();


  stockStatus.className =
    "stock-status";


  if (
    availableStock <= 0
  ) {

    stockStatus.textContent =
      "Out of stock";


    stockStatus.classList.add(
      "out-of-stock"
    );


    stockNumber.textContent =
      "";


    disablePurchaseButton();

    return;
  }


  if (
    availableStock <= 5
  ) {

    stockStatus.textContent =
      "Low stock";


    stockStatus.classList.add(
      "low-stock"
    );

  } else {

    stockStatus.textContent =
      "In stock";


    stockStatus.classList.add(
      "in-stock"
    );
  }


  stockNumber.textContent =
    `${availableStock} available`;


  updateAddToCartButton();
}


/* =========================================================
   IMAGES
========================================================= */

function renderImages() {

  selectedImageIndex = 0;


  if (
    productImages.length === 0
  ) {

    mainProductImage.src =
      createImagePlaceholder();


    mainProductImage.alt =
      currentProduct.name ||
      "Product";


    imageBadge.style.display =
      "none";


    thumbnailList.innerHTML =
      "";


    return;
  }


  thumbnailList.innerHTML =
    productImages
      .map(
        (
          image,
          index
        ) => {

          return `
            <button
              type="button"
              class="thumbnail ${
                index === 0
                  ? "active"
                  : ""
              }"
              data-image-index="${index}"
              aria-label="View image ${index + 1}"
            >

              <img
                src="${escapeAttribute(
                  image
                )}"
                alt="${escapeAttribute(
                  currentProduct.name ||
                    "Product"
                )}"
                loading="lazy"
              >

            </button>
          `;
        }
      )
      .join("");


  thumbnailList
    .querySelectorAll(
      ".thumbnail"
    )
    .forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            const index =
              Number(
                button.dataset
                  .imageIndex
              );


            showImage(
              index
            );
          }
        );
      }
    );


  renderMainImage();
}


function renderMainImage() {

  const image =
    productImages[
      selectedImageIndex
    ];


  if (!image) {
    return;
  }


  mainProductImage.src =
    image;


  mainProductImage.alt =
    currentProduct.name ||
    "Product";


  imageBadge.textContent =
    `${selectedImageIndex + 1} / ${productImages.length}`;


  imageBadge.style.display =
    productImages.length > 1
      ? "block"
      : "none";


  thumbnailList
    .querySelectorAll(
      ".thumbnail"
    )
    .forEach(
      (
        button,
        index
      ) => {

        button.classList.toggle(
          "active",
          index ===
            selectedImageIndex
        );
      }
    );
}


function showImage(
  index
) {

  if (
    index < 0 ||
    index >=
      productImages.length
  ) {

    return;
  }


  selectedImageIndex =
    index;


  renderMainImage();
}


function createImagePlaceholder() {

  const svg = `
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="600"
      height="600"
      viewBox="0 0 600 600"
    >

      <rect
        width="600"
        height="600"
        fill="#f4f4f4"
      />

      <text
        x="300"
        y="300"
        text-anchor="middle"
        dominant-baseline="middle"
        font-family="Arial"
        font-size="28"
        fill="#aaaaaa"
      >
        No Image
      </text>

    </svg>
  `;


  return (
    "data:image/svg+xml;charset=UTF-8," +
    encodeURIComponent(
      svg
    )
  );
}


/* =========================================================
   VARIANTS
========================================================= */

function groupVariants(
  variants
) {

  const groups = {};


  variants.forEach(
    variant => {

      const name =
        variant.variant_name ||
        "Option";


      if (
        !groups[name]
      ) {

        groups[name] = [];
      }


      groups[name].push(
        variant
      );
    }
  );


  return groups;
}


function renderVariants() {

  if (
    productVariants.length ===
    0
  ) {

    variantsSection.style.display =
      "none";


    variantsContainer.innerHTML =
      "";


    return;
  }


  variantsSection.style.display =
    "block";


  const groups =
    groupVariants(
      productVariants
    );


  variantsContainer.innerHTML =
    Object.entries(
      groups
    )
      .map(
        (
          [
            groupName,
            rows
          ]
        ) => {

          return `
            <div
              class="variant-group"
            >

              <span
                class="variant-group-title"
              >
                ${escapeHtml(
                  groupName
                )}
              </span>


              <div
                class="variant-options"
              >

                ${rows
                  .map(
                    row => {

                      const stock =
                        Number(
                          row.stock_quantity
                        ) || 0;


                      const selected =
                        selectedVariants[
                          groupName
                        ]?.id ===
                        row.id;


                      return `
                        <button
                          type="button"
                          class="variant-option ${
                            selected
                              ? "selected"
                              : ""
                          } ${
                            stock <= 0
                              ? "disabled"
                              : ""
                          }"
                          data-variant-id="${
                            row.id
                          }"
                          data-variant-group="${escapeAttribute(
                            groupName
                          )}"
                          ${
                            stock <= 0
                              ? "disabled"
                              : ""
                          }
                        >
                          ${escapeHtml(
                            row.variant_value
                          )}
                        </button>
                      `;
                    }
                  )
                  .join("")}

              </div>

            </div>
          `;
        }
      )
      .join("");


  variantsContainer
    .querySelectorAll(
      ".variant-option"
    )
    .forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            const group =
              button.dataset
                .variantGroup;


            const variantId =
              button.dataset
                .variantId;


            const variant =
              productVariants.find(
                item =>
                  String(
                    item.id
                  ) ===
                  String(
                    variantId
                  )
              );


            if (!variant) {
              return;
            }


            selectedVariants[
              group
            ] =
              variant;


            renderVariants();

            renderPrice();

            renderStock();

            updateAddToCartButton();
          }
        );
      }
    );
}


function allRequiredVariantsSelected() {

  if (
    productVariants.length ===
    0
  ) {

    return true;
  }


  const groups =
    groupVariants(
      productVariants
    );


  return Object.keys(
    groups
  ).every(
    groupName =>
      Boolean(
        selectedVariants[
          groupName
        ]
      )
  );
}


/* =========================================================
   BUTTON SETUP
========================================================= */

function setupButtons() {

  if (
    addToCartButton
  ) {

    addToCartButton.addEventListener(
      "click",
      addToCart
    );
  }


  if (
    backButton
  ) {

    backButton.addEventListener(
      "click",
      goBack
    );
  }


  if (
    backToShop
  ) {

    backToShop.addEventListener(
      "click",
      () => {

        window.location.href =
          "index.html";

      }
    );
  }


  if (
    cartButton
  ) {

    cartButton.addEventListener(
      "click",
      () => {

        window.location.href =
          "cart.html";

      }
    );
  }
}


/* =========================================================
   CART
========================================================= */

function getCart() {

  try {

    const saved =
      localStorage.getItem(
        CART_KEY
      );


    if (!saved) {
      return [];
    }


    const parsed =
      JSON.parse(
        saved
      );


    return Array.isArray(
      parsed
    )
      ? parsed
      : [];

  } catch (error) {

    console.error(
      "CART READ ERROR:",
      error
    );


    return [];
  }
}


function saveCart(
  cart
) {

  try {

    localStorage.setItem(
      CART_KEY,
      JSON.stringify(
        cart
      )
    );


    updateCartCount();

    notifyCartChanged();

  } catch (error) {

    console.error(
      "CART SAVE ERROR:",
      error
    );


    showToast(
      "Unable to save cart."
    );
  }
}


function getCartItemVariantText() {

  return getSelectedVariantRows()
    .map(
      row =>
        `${row.variant_name}: ${row.variant_value}`
    )
    .join(", ");
}


function buildVariantData() {

  return getSelectedVariantRows()
    .map(
      row => ({
        id: row.id,

        name:
          row.variant_name,

        value:
          row.variant_value,

        sku:
          row.sku || null
      })
    );
}


function createCartItem() {

  return {

    product_id:
      currentProduct.id,

    product_name:
      currentProduct.name,

    product_image:
      productImages[0] ||
      "",

    quantity:
      1,

    unit_price:
      getCurrentUnitPrice(),

    variant:
      getCartItemVariantText(),

    variant_selections:
      buildVariantData(),

    added_at:
      new Date().toISOString()
  };
}


function isCurrentProductInCart() {

  if (
    !currentProduct
  ) {

    return false;
  }


  const cart =
    getCart();


  const currentVariant =
    getCartItemVariantText();


  return cart.some(
    item => {

      return (
        String(
          item.product_id
        ) ===
          String(
            currentProduct.id
          ) &&

        String(
          item.variant || ""
        ) ===
          String(
            currentVariant
          )
      );
    }
  );
}


/* =========================================================
   ADD TO CART
========================================================= */

function addToCart() {

  if (
    !currentProduct
  ) {

    return;
  }


  if (
    !allRequiredVariantsSelected()
  ) {

    showToast(
      "Please select all product options."
    );


    return;
  }


  if (
    availableStock <= 0
  ) {

    showToast(
      "This product is out of stock."
    );


    return;
  }


  const cart =
    getCart();


  const currentVariant =
    getCartItemVariantText();


  const alreadyExists =
    cart.some(
      item => {

        return (
          String(
            item.product_id
          ) ===
            String(
              currentProduct.id
            ) &&

          String(
            item.variant || ""
          ) ===
            String(
              currentVariant
            )
        );
      }
    );


  /*
    DO NOT ADD THE SAME PRODUCT
    AND SAME VARIANT AGAIN.
  */

  if (
    alreadyExists
  ) {

    showToast(
      "Already added to cart."
    );


    updateAddToCartButton();


    return;
  }


  /*
    ADD ONE ITEM TO CART.
    QUANTITY IS MANAGED
    INSIDE THE CART PAGE.
  */

  cart.push(
    createCartItem()
  );


  saveCart(
    cart
  );


  updateAddToCartButton();


  showToast(
    "Added to cart."
  );
}


/* =========================================================
   ADD TO CART BUTTON STATE
========================================================= */

function updateAddToCartButton() {

  if (
    !addToCartButton
  ) {

    return;
  }


  /*
    No product yet.
  */

  if (
    !currentProduct
  ) {

    addToCartButton.disabled =
      true;


    return;
  }


  /*
    Out of stock.
  */

  if (
    availableStock <= 0
  ) {

    addToCartButton.disabled =
      true;


    addToCartButton.innerHTML =
      "Out of Stock";


    addToCartButton.classList.remove(
      "already-added"
    );


    return;
  }


  /*
    Product has variants,
    but customer has not selected
    every required option.
  */

  if (
    productVariants.length > 0 &&
    !allRequiredVariantsSelected()
  ) {

    addToCartButton.disabled =
      true;


    addToCartButton.innerHTML =
      "🛒 Add to Cart";


    addToCartButton.classList.remove(
      "already-added"
    );


    return;
  }


  /*
    Product is already inside cart.
  */

  if (
    isCurrentProductInCart()
  ) {

    addToCartButton.disabled =
      false;


    addToCartButton.innerHTML =
      "✓ Already Added";


    addToCartButton.classList.add(
      "already-added"
    );


    return;
  }


  /*
    Product is not inside cart.
  */

  addToCartButton.disabled =
    false;


  addToCartButton.innerHTML =
    "🛒 Add to Cart";


  addToCartButton.classList.remove(
    "already-added"
  );
}


/* =========================================================
   PURCHASE BUTTON
========================================================= */

function disablePurchaseButton() {

  if (
    addToCartButton
  ) {

    addToCartButton.disabled =
      true;


    addToCartButton.innerHTML =
      "Out of Stock";
  }
}


/* =========================================================
   CART COUNT
========================================================= */

function updateCartCount() {

  if (
    !cartCount
  ) {

    return;
  }


  const cart =
    getCart();


  const totalQuantity =
    cart.reduce(
      (
        total,
        item
      ) => {

        return (
          total +
          (
            Number(
              item.quantity
            ) || 0
          )
        );

      },
      0
    );


  cartCount.textContent =
    totalQuantity > 99
      ? "99+"
      : totalQuantity;


  cartCount.style.display =
    totalQuantity > 0
      ? "flex"
      : "none";
}


/* =========================================================
   CART CHANGE NOTIFICATION
========================================================= */

function notifyCartChanged() {

  window.dispatchEvent(
    new CustomEvent(
      "marketHubCartUpdated",
      {
        detail: {
          cart:
            getCart()
        }
      }
    )
  );
}


/* =========================================================
   CART SYNC
========================================================= */

window.addEventListener(
  "pageshow",
  () => {

    updateCartCount();

    updateAddToCartButton();
  }
);


window.addEventListener(
  "marketHubCartUpdated",
  () => {

    updateCartCount();

    updateAddToCartButton();
  }
);


window.addEventListener(
  "storage",
  event => {

    if (
      event.key ===
      CART_KEY
    ) {

      updateCartCount();

      updateAddToCartButton();
    }
  }
);


/* =========================================================
   NAVIGATION
========================================================= */

function goBack() {

  if (
    window.history.length > 1
  ) {

    window.history.back();

  } else {

    window.location.href =
      "index.html";
  }
}


/* =========================================================
   LOADING / ERROR
========================================================= */

function hideLoading() {

  if (
    loadingState
  ) {

    loadingState.style.display =
      "none";
  }


  if (
    errorState
  ) {

    errorState.style.display =
      "none";
  }
}


function showError(
  message
) {

  if (
    loadingState
  ) {

    loadingState.style.display =
      "none";
  }


  if (
    productContent
  ) {

    productContent.style.display =
      "none";
  }


  if (
    errorState
  ) {

    errorState.style.display =
      "flex";
  }


  if (
    errorMessage
  ) {

    errorMessage.textContent =
      message;
  }
}


/* =========================================================
   TOAST
========================================================= */

function showToast(
  message
) {

  if (
    !toast
  ) {

    return;
  }


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  clearTimeout(
    toastTimer
  );


  toastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2200
    );
}


/* =========================================================
   FORMAT NAIRA
========================================================= */

function formatNaira(
  amount
) {

  const value =
    Number(
      amount
    ) || 0;


  return new Intl.NumberFormat(
    "en-NG",
    {
      style:
        "currency",

      currency:
        "NGN",

      maximumFractionDigits:
        0
    }
  ).format(
    value
  );
}


/* =========================================================
   HTML SAFETY
========================================================= */

function escapeHtml(
  value
) {

  return String(
    value ?? ""
  )
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    )
    .replace(
      /"/g,
      "&quot;"
    )
    .replace(
      /'/g,
      "&#039;"
    );
}


function escapeAttribute(
  value
) {

  return escapeHtml(
    value
  );
}