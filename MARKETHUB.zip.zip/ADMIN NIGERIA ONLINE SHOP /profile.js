/* =========================================================
   MARKET HUB — CUSTOMER PROFILE
========================================================= */


/* =========================================================
   SUPABASE CONFIG
========================================================= */

const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const supabaseClient =
  window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


const PROFILE_BUCKET =
  "market-hub-profiles";


/* =========================================================
   STATE
========================================================= */

let currentUser = null;
let currentProfile = null;
let selectedPhotoFile = null;

let allowCustomerProfileEdit = true;


/* =========================================================
   ELEMENTS
========================================================= */

const profileImage =
  document.getElementById("profileImage");

const profilePlaceholder =
  document.getElementById("photoPlaceholder");

const profileName =
  document.getElementById("profileName");

const profileEmail =
  document.getElementById("profileEmail");

const profilePhone =
  document.getElementById("profilePhone");

const editProfileBtn =
  document.getElementById("editProfileBtn");

const editModal =
  document.getElementById("editModal");

const closeEditModal =
  document.getElementById("closeEditModal");

const editProfileImage =
  document.getElementById("editProfileImage");

const editPhotoPlaceholder =
  document.getElementById("editPhotoPlaceholder");

const profileFileInput =
  document.getElementById("profileFileInput");

const fullNameInput =
  document.getElementById("fullNameInput");

const emailInput =
  document.getElementById("emailInput");

const phoneInput =
  document.getElementById("phoneInput");

const saveProfileBtn =
  document.getElementById("saveProfileBtn");

const ordersBtn =
  document.getElementById("ordersBtn");

const passwordBtn =
  document.getElementById("passwordBtn");

const supportBtn =
  document.getElementById("supportBtn");

const termsBtn =
  document.getElementById("termsBtn");

const logoutBtn =
  document.getElementById("logoutBtn");

const passwordModal =
  document.getElementById("passwordModal");

const closePasswordModal =
  document.getElementById("closePasswordModal");

const currentPassword =
  document.getElementById("currentPassword");

const newPassword =
  document.getElementById("newPassword");

const confirmPassword =
  document.getElementById("confirmPassword");

const changePasswordBtn =
  document.getElementById("changePasswordBtn");

const messageModal =
  document.getElementById("messageModal");

const closeMessageModal =
  document.getElementById("closeMessageModal");

const messageContent =
  document.getElementById("messageContent");

const toast =
  document.getElementById("toast");

const backBtn =
  document.getElementById("backBtn");


/* =========================================================
   START
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  initProfile
);

async function initProfile() {

  setupButtons();


  /*
    Check authentication before
    loading any customer profile data.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {

    return;

  }


  await loadCustomerSettings();

  await loadCurrentUser();

}


/* =========================================================
   CUSTOMER SETTINGS
========================================================= */

async function loadCustomerSettings() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient
        .from("market_hub_settings")
        .select(
          "allow_customer_profile_edit"
        )
        .eq("id", 1)
        .maybeSingle();


    if (error) {

      console.error(
        "CUSTOMER SETTINGS ERROR:",
        error
      );

      /*
        If the setting cannot be read,
        keep profile editing available so
        an existing customer is not locked
        out by a temporary settings-read error.
      */

      allowCustomerProfileEdit = true;

      return;
    }


    allowCustomerProfileEdit =
      data?.allow_customer_profile_edit !== false;


    updateEditButtonState();


  } catch (error) {

    console.error(
      "CUSTOMER SETTINGS ERROR:",
      error
    );

    allowCustomerProfileEdit = true;

    updateEditButtonState();
  }
}


/* =========================================================
   EDIT BUTTON STATE
========================================================= */

function updateEditButtonState() {

  if (!editProfileBtn) {
    return;
  }


  if (!allowCustomerProfileEdit) {

    editProfileBtn.disabled = true;

    editProfileBtn.style.opacity = "0.55";

    editProfileBtn.style.cursor =
      "not-allowed";

    editProfileBtn.setAttribute(
      "aria-disabled",
      "true"
    );

    editProfileBtn.title =
      "Profile editing is currently disabled.";

  } else {

    editProfileBtn.disabled = false;

    editProfileBtn.style.opacity = "";

    editProfileBtn.style.cursor = "";

    editProfileBtn.removeAttribute(
      "aria-disabled"
    );

    editProfileBtn.removeAttribute(
      "title"
    );
  }
}


/* =========================================================
   AUTH
========================================================= */

async function loadCurrentUser() {

  try {

    const {
      data: {
        session
      },
      error
    } =
      await supabaseClient.auth.getSession();


    if (error) {

      console.error(error);

      showToast(
        "Unable to load your account."
      );

      return;
    }


if (
  !session ||
  !session.user
) {

  currentUser = null;


  window.location.replace(
    "login.html"
  );


  return;
}
    

    currentUser =
      session.user;


    await loadProfile();


  } catch (error) {

    console.error(
      "AUTH ERROR:",
      error
    );

    showToast(
      "Something went wrong."
    );
  }
}


/* =========================================================
   PROFILE
========================================================= */

async function loadProfile() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient
        .from("profiles")
        .select("*")
        .eq("id", currentUser.id)
        .maybeSingle();


    if (error) {

      console.error(
        "PROFILE LOAD ERROR:",
        error
      );

      showToast(
        "Unable to load profile."
      );

      return;
    }


    currentProfile =
      data || null;


    displayProfile();


  } catch (error) {

    console.error(error);

    showToast(
      "Unable to load profile."
    );
  }
}


/* =========================================================
   DISPLAY PROFILE
========================================================= */

function displayProfile() {

  const fallbackEmail =
    currentUser?.email || "";


  const name =
    currentProfile?.full_name ||
    currentUser?.user_metadata?.full_name ||
    "MarketHub Customer";


  const email =
    currentProfile?.email ||
    fallbackEmail ||
    "No email available";


  const phone =
    currentProfile?.phone || "";


  profileName.textContent =
    name;

  profileEmail.textContent =
    email;


  if (phone) {

    profilePhone.textContent =
      phone;

    profilePhone.style.display =
      "block";

  } else {

    profilePhone.textContent = "";

    profilePhone.style.display =
      "none";
  }


  const avatar =
    currentProfile?.avatar_url || "";


  if (avatar) {

    profileImage.src =
      avatar;

    profileImage.style.display =
      "block";

    profilePlaceholder.style.display =
      "none";

  } else {

    profileImage.removeAttribute(
      "src"
    );

    profileImage.style.display =
      "none";

    profilePlaceholder.style.display =
      "flex";
  }


  updateEditButtonState();
}


/* =========================================================
   EDIT PROFILE
========================================================= */

function openEditProfile() {

  if (!currentUser) {

    showToast(
      "Please log in first."
    );

    return;
  }


  /*
    Re-check the setting immediately before
    opening the editor.
  */

  if (!allowCustomerProfileEdit) {

    showToast(
      "Profile editing is currently disabled."
    );

    return;
  }


  fullNameInput.value =
    currentProfile?.full_name ||
    currentUser?.user_metadata?.full_name ||
    "";


  emailInput.value =
    currentProfile?.email ||
    currentUser?.email ||
    "";


  phoneInput.value =
    currentProfile?.phone ||
    "";


  selectedPhotoFile =
    null;


  const avatar =
    currentProfile?.avatar_url || "";


  if (avatar) {

    editProfileImage.src =
      avatar;

    editProfileImage.style.display =
      "block";

    editPhotoPlaceholder.style.display =
      "none";

  } else {

    editProfileImage.removeAttribute(
      "src"
    );

    editProfileImage.style.display =
      "none";

    editPhotoPlaceholder.style.display =
      "flex";
  }


  editModal.classList.add(
    "active"
  );

  document.body.style.overflow =
    "hidden";
}


function closeEditProfile() {

  editModal.classList.remove(
    "active"
  );

  document.body.style.overflow =
    "";

  selectedPhotoFile =
    null;

  profileFileInput.value =
    "";
}


/* =========================================================
   PHOTO
========================================================= */

profileFileInput.addEventListener(
  "change",
  handlePhotoSelection
);


function handlePhotoSelection(event) {

  if (!allowCustomerProfileEdit) {

    showToast(
      "Profile editing is currently disabled."
    );

    profileFileInput.value =
      "";

    return;
  }


  const file =
    event.target.files?.[0];


  if (!file) {
    return;
  }


  if (
    !file.type.startsWith(
      "image/"
    )
  ) {

    showToast(
      "Please select an image."
    );

    profileFileInput.value =
      "";

    return;
  }


  if (
    file.size >
    5 * 1024 * 1024
  ) {

    showToast(
      "Image must be smaller than 5MB."
    );

    profileFileInput.value =
      "";

    return;
  }


  selectedPhotoFile =
    file;


  const previewUrl =
    URL.createObjectURL(file);


  editProfileImage.src =
    previewUrl;

  editProfileImage.style.display =
    "block";

  editPhotoPlaceholder.style.display =
    "none";
}


/* =========================================================
   SAVE PROFILE
========================================================= */

saveProfileBtn.addEventListener(
  "click",
  saveProfile
);


async function saveProfile() {

  if (!currentUser) {

    showToast(
      "Please log in first."
    );

    return;
  }


  /*
    Final permission check.
    This prevents saving if the Admin has
    disabled editing after the page loaded.
  */

  await refreshProfileEditSetting();


  if (!allowCustomerProfileEdit) {

    showToast(
      "Profile editing is currently disabled."
    );

    closeEditProfile();

    return;
  }


  const fullName =
    fullNameInput.value.trim();


  const email =
    emailInput.value.trim();


  const phone =
    phoneInput.value.trim();


  if (!fullName) {

    showToast(
      "Please enter your full name."
    );

    fullNameInput.focus();

    return;
  }


  if (!email) {

    showToast(
      "Please enter your email."
    );

    emailInput.focus();

    return;
  }


  saveProfileBtn.disabled =
    true;

  saveProfileBtn.textContent =
    "Saving...";


  try {

    let avatarUrl =
      currentProfile?.avatar_url ||
      null;


    /* -----------------------------------------
       UPLOAD PHOTO
    ----------------------------------------- */

    if (selectedPhotoFile) {

      const extension =
        getFileExtension(
          selectedPhotoFile.name
        );


      const filePath =
        `${currentUser.id}/${Date.now()}.${extension}`;


      const {
        error: uploadError
      } =
        await supabaseClient
          .storage
          .from(PROFILE_BUCKET)
          .upload(
            filePath,
            selectedPhotoFile,
            {
              cacheControl:
                "3600",

              upsert:
                false,

              contentType:
                selectedPhotoFile.type
            }
          );


      if (uploadError) {

        console.error(
          "PROFILE PHOTO UPLOAD ERROR:",
          uploadError
        );

        throw new Error(
          "Unable to upload profile photo."
        );
      }


      const {
        data: publicUrlData
      } =
        supabaseClient
          .storage
          .from(PROFILE_BUCKET)
          .getPublicUrl(
            filePath
          );


      avatarUrl =
        publicUrlData?.publicUrl ||
        null;
    }


    /* -----------------------------------------
       PROFILE DATA
    ----------------------------------------- */

    const profileData = {

      id:
        currentUser.id,

      full_name:
        fullName,

      email:
        email,

      phone:
        phone || null,

      avatar_url:
        avatarUrl,

      updated_at:
        new Date().toISOString()
    };


    /* -----------------------------------------
       SAVE PROFILE
    ----------------------------------------- */

    const {
      data,
      error
    } =
      await supabaseClient
        .from("profiles")
        .upsert(
          profileData,
          {
            onConflict:
              "id"
          }
        )
        .select()
        .single();


    if (error) {

      console.error(
        "PROFILE SAVE ERROR:",
        error
      );

      throw new Error(
        error.message ||
        "Unable to save profile."
      );
    }


    currentProfile =
      data;


    displayProfile();

    closeEditProfile();


    showToast(
      "Profile updated successfully."
    );


  } catch (error) {

    console.error(error);

    showToast(
      error.message ||
      "Unable to save profile."
    );


  } finally {

    saveProfileBtn.disabled =
      false;

    saveProfileBtn.textContent =
      "Save Changes";
  }
}


/* =========================================================
   REFRESH PROFILE EDIT SETTING
========================================================= */

async function refreshProfileEditSetting() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient
        .from("market_hub_settings")
        .select(
          "allow_customer_profile_edit"
        )
        .eq("id", 1)
        .maybeSingle();


    if (error) {

      console.error(
        "PROFILE EDIT SETTING ERROR:",
        error
      );

      return;
    }


    allowCustomerProfileEdit =
      data?.allow_customer_profile_edit !== false;


    updateEditButtonState();


  } catch (error) {

    console.error(
      "PROFILE EDIT SETTING ERROR:",
      error
    );
  }
}


/* =========================================================
   CHANGE PASSWORD
========================================================= */

function openPasswordModal() {

  currentPassword.value = "";

  newPassword.value = "";

  confirmPassword.value = "";


  passwordModal.classList.add(
    "active"
  );

  document.body.style.overflow =
    "hidden";
}


function closePasswordModalFunction() {

  passwordModal.classList.remove(
    "active"
  );

  document.body.style.overflow =
    "";
}


changePasswordBtn.addEventListener(
  "click",
  changePassword
);


async function changePassword() {

  if (!currentUser) {

    showToast(
      "Please log in first."
    );

    return;
  }


  const current =
    currentPassword.value;

  const newPass =
    newPassword.value;

  const confirm =
    confirmPassword.value;


  if (!current) {

    showToast(
      "Enter your current password."
    );

    currentPassword.focus();

    return;
  }


  if (!newPass) {

    showToast(
      "Enter your new password."
    );

    newPassword.focus();

    return;
  }


  if (newPass.length < 6) {

    showToast(
      "New password must be at least 6 characters."
    );

    newPassword.focus();

    return;
  }


  if (newPass !== confirm) {

    showToast(
      "New passwords do not match."
    );

    confirmPassword.focus();

    return;
  }


  changePasswordBtn.disabled =
    true;

  changePasswordBtn.textContent =
    "Changing...";


  try {

    /* -----------------------------------------
       VERIFY CURRENT PASSWORD
    ----------------------------------------- */

    const {
      error: verifyError
    } =
      await supabaseClient.auth
        .signInWithPassword({
          email:
            currentUser.email,

          password:
            current
        });


    if (verifyError) {

      console.error(
        "CURRENT PASSWORD ERROR:",
        verifyError
      );

      throw new Error(
        "Current password is incorrect."
      );
    }


    /* -----------------------------------------
       UPDATE PASSWORD
    ----------------------------------------- */

    const {
      error: updateError
    } =
      await supabaseClient.auth
        .updateUser({
          password:
            newPass
        });


    if (updateError) {

      console.error(
        "PASSWORD UPDATE ERROR:",
        updateError
      );

      throw new Error(
        updateError.message ||
        "Unable to change password."
      );
    }


    closePasswordModalFunction();


    showToast(
      "Password changed successfully."
    );


  } catch (error) {

    console.error(error);

    showToast(
      error.message ||
      "Unable to change password."
    );


  } finally {

    changePasswordBtn.disabled =
      false;

    changePasswordBtn.textContent =
      "Change Password";
  }
}


/* =========================================================
   SUPPORT
========================================================= */

function showSupport() {

  openMessage(
    "Support",
    `
      <p>
        Need help with your MarketHub account,
        orders, payments, or deliveries?
      </p>

      <p style="margin-top:12px;">
        Please contact MarketHub support and
        include your order ID when asking about
        an order.
      </p>
    `
  );
}


/* =========================================================
   TERMS & PRIVACY
========================================================= */

function showTerms() {

  openMessage(
    "Terms & Privacy",
    `
      <p>
        MarketHub respects your privacy and
        protects the information you provide
        while using the marketplace.
      </p>

      <p style="margin-top:12px;">
        Your account information is used to
        provide shopping, payment, order and
        delivery services.
      </p>

      <p style="margin-top:12px;">
        By using MarketHub, you agree to follow
        the applicable marketplace terms and
        policies.
      </p>
    `
  );
}


/* =========================================================
   MESSAGE MODAL
========================================================= */

function openMessage(
  title,
  html
) {

  messageContent.innerHTML = `
    <h2>${title}</h2>
    ${html}
  `;


  messageModal.classList.add(
    "active"
  );

  document.body.style.overflow =
    "hidden";
}


function closeMessage() {

  messageModal.classList.remove(
    "active"
  );

  document.body.style.overflow =
    "";
}


/* =========================================================
   LOGOUT
========================================================= */

async function logout() {

  const confirmed =
    window.confirm(
      "Are you sure you want to logout?"
    );


  if (!confirmed) {
    return;
  }


  logoutBtn.disabled =
    true;

  logoutBtn.textContent =
    "Logging out...";


  try {

    const {
      error
    } =
      await supabaseClient.auth
        .signOut();


    if (error) {
      throw error;
    }


    window.location.href =
      "login.html";


  } catch (error) {

    console.error(
      "LOGOUT ERROR:",
      error
    );


    showToast(
      "Unable to logout. Please try again."
    );


    logoutBtn.disabled =
      false;

    logoutBtn.innerHTML =
      "<span>↪</span> Logout";
  }
}


/* =========================================================
   BUTTONS
========================================================= */

function setupButtons() {

  if (editProfileBtn) {

    editProfileBtn.addEventListener(
      "click",
      openEditProfile
    );
  }


  if (closeEditModal) {

    closeEditModal.addEventListener(
      "click",
      closeEditProfile
    );
  }


  if (editModal) {

    editModal.addEventListener(
      "click",
      event => {

        if (
          event.target ===
          editModal
        ) {

          closeEditProfile();
        }
      }
    );
  }


  if (passwordBtn) {

    passwordBtn.addEventListener(
      "click",
      openPasswordModal
    );
  }


  if (closePasswordModal) {

    closePasswordModal.addEventListener(
      "click",
      closePasswordModalFunction
    );
  }


  if (passwordModal) {

    passwordModal.addEventListener(
      "click",
      event => {

        if (
          event.target ===
          passwordModal
        ) {

          closePasswordModalFunction();
        }
      }
    );
  }


  if (supportBtn) {

    supportBtn.addEventListener(
      "click",
      showSupport
    );
  }


  if (termsBtn) {

    termsBtn.addEventListener(
      "click",
      showTerms
    );
  }


  if (closeMessageModal) {

    closeMessageModal.addEventListener(
      "click",
      closeMessage
    );
  }


  if (messageModal) {

    messageModal.addEventListener(
      "click",
      event => {

        if (
          event.target ===
          messageModal
        ) {

          closeMessage();
        }
      }
    );
  }


  if (logoutBtn) {

    logoutBtn.addEventListener(
      "click",
      logout
    );
  }


  if (ordersBtn) {

    ordersBtn.addEventListener(
      "click",
      () => {

        window.location.href =
          "orders.html";
      }
    );
  }


  if (backBtn) {

    backBtn.addEventListener(
      "click",
      () => {

        if (
          document.referrer &&
          document.referrer.includes(
            window.location.hostname
          )
        ) {

          window.history.back();

        } else {

          window.location.href =
            "index.html";
        }
      }
    );
  }
}


/* =========================================================
   HELPERS
========================================================= */

function getFileExtension(
  filename
) {

  const parts =
    filename.split(".");


  if (parts.length < 2) {
    return "jpg";
  }


  const extension =
    parts
      .pop()
      .toLowerCase();


  const allowed = [
    "jpg",
    "jpeg",
    "png",
    "webp",
    "gif"
  ];


  if (
    !allowed.includes(
      extension
    )
  ) {

    return "jpg";
  }


  return extension;
}


/* =========================================================
   TOAST
========================================================= */

function showToast(message) {

  if (!toast) {

    alert(message);

    return;
  }


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  clearTimeout(
    showToast.timeout
  );


  showToast.timeout =
    setTimeout(() => {

      toast.classList.remove(
        "show"
      );

    }, 2800);
}