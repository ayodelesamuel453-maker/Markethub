const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";


const { createClient } =
  supabase;


const db =
  createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await db.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


const CART_KEY =
  "marketHubCart";


let cart = [];

let products = [];

let toastTimer = null;


// =====================================
// ELEMENTS
// =====================================

const backButton =
  document.getElementById(
    "backButton"
  );

const cartItemLabel =
  document.getElementById(
    "cartItemLabel"
  );

const clearCartButton =
  document.getElementById(
    "clearCartButton"
  );

const loadingState =
  document.getElementById(
    "loadingState"
  );

const emptyState =
  document.getElementById(
    "emptyState"
  );

const shopNowButton =
  document.getElementById(
    "shopNowButton"
  );

const cartContent =
  document.getElementById(
    "cartContent"
  );

const selectedLabel =
  document.getElementById(
    "selectedLabel"
  );

const cartItems =
  document.getElementById(
    "cartItems"
  );

const summaryItems =
  document.getElementById(
    "summaryItems"
  );

const summarySubtotal =
  document.getElementById(
    "summarySubtotal"
  );

const summaryDelivery =
  document.getElementById(
    "summaryDelivery"
  );

const summaryTotal =
  document.getElementById(
    "summaryTotal"
  );

const checkoutButton =
  document.getElementById(
    "checkoutButton"
  );

const continueShoppingButton =
  document.getElementById(
    "continueShoppingButton"
  );

const toast =
  document.getElementById(
    "toast"
  );

const confirmOverlay =
  document.getElementById(
    "confirmOverlay"
  );

const cancelClearButton =
  document.getElementById(
    "cancelClearButton"
  );

const confirmClearButton =
  document.getElementById(
    "confirmClearButton"
  );


// =====================================
// MONEY
// =====================================

function formatMoney(
  value
) {

  return new Intl.NumberFormat(
    "en-NG",
    {
      style: "currency",
      currency: "NGN",
      maximumFractionDigits: 0
    }
  ).format(
    Number(value) || 0
  );

}


// =====================================
// ESCAPE
// =====================================

function escapeHTML(
  value
) {

  return String(
    value ?? ""
  )
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    )
    .replace(
      /"/g,
      "&quot;"
    )
    .replace(
      /'/g,
      "&#039;"
    );

}


// =====================================
// PRODUCT ID
// =====================================

function getProductId(
  item
) {

  return String(
    item.product_id ??
    item.productId ??
    item.id ??
    ""
  );

}


// =====================================
// QUANTITY
// =====================================

function getQuantity(
  item
) {

  const quantity =
    Number(
      item.quantity
    );

  return quantity > 0
    ? quantity
    : 1;

}


// =====================================
// LOAD CART
// =====================================

function loadCart() {

  try {

    const saved =
      localStorage.getItem(
        CART_KEY
      );


    if (!saved) {

      cart = [];

      return;

    }


    const parsed =
      JSON.parse(
        saved
      );


    cart =
      Array.isArray(
        parsed
      )
        ? parsed
        : [];

  } catch (
    error
  ) {

    console.error(
      "CART ERROR:",
      error
    );

    cart = [];

  }

}


// =====================================
// SAVE CART
// =====================================

function saveCart() {

  localStorage.setItem(
    CART_KEY,
    JSON.stringify(
      cart
    )
  );


  window.dispatchEvent(
    new CustomEvent(
      "marketHubCartUpdated"
    )
  );

}


// =====================================
// PRODUCT IMAGE
// =====================================

function getProductImage(
  product
) {

  if (!product) {
    return "";
  }


  const images =
    product.images;


  if (
    Array.isArray(images)
  ) {

    return (
      images[0] || ""
    );

  }


  if (
    typeof images ===
    "string"
  ) {

    try {

      const parsed =
        JSON.parse(
          images
        );


      if (
        Array.isArray(
          parsed
        )
      ) {

        return (
          parsed[0] || ""
        );

      }


      if (
        typeof parsed ===
        "string"
      ) {

        return parsed;

      }

    } catch {

      return images;

    }

  }


  return "";

}


// =====================================
// LOAD PRODUCTS
// =====================================

async function loadProducts() {

  if (!cart.length) {

    products = [];

    return;

  }


  const ids =
    [
      ...new Set(
        cart
          .map(
            item =>
              getProductId(item)
          )
          .filter(Boolean)
      )
    ];


  if (!ids.length) {

    products = [];

    return;

  }


  const {
    data,
    error
  } = await db
    .from("products")
    .select(`
      id,
      name,
      price,
      stock,
      images,
      flash_sale,
      flash_price,
      status
    `)
    .in(
      "id",
      ids
    );


  if (error) {

    console.error(
      "PRODUCT QUERY ERROR:",
      error
    );

    throw error;

  }


  products =
    Array.isArray(data)
      ? data
      : [];

}


// =====================================
// FIND PRODUCT
// =====================================

function findProduct(
  id
) {

  return products.find(
    product =>
      String(
        product.id
      ) ===
      String(id)
  );

}


// =====================================
// PRODUCT DATA
// =====================================

function getProductData(
  item
) {

  const product =
    findProduct(
      getProductId(item)
    );


  if (!product) {

    return {

      product: null,

      name:
        item.name ||
        "Product",

      image:
        item.image_url ||
        item.image ||
        "",

      price:
        Number(
          item.price
        ) || 0,

      stock:
        Number(
          item.stock
        ) || 0

    };

  }


  let price =
    Number(
      product.price
    ) || 0;


  if (
    product.flash_sale &&
    product.flash_price !== null &&
    product.flash_price !== undefined
  ) {

    price =
      Number(
        product.flash_price
      ) || price;

  }


  return {

    product,

    name:
      product.name,

    image:
      getProductImage(
        product
      ),

    price,

    stock:
      Number(
        product.stock
      ) || 0

  };

}


// =====================================
// HEADER
// =====================================

function updateHeader() {

  const count =
    cart.reduce(
      (
        total,
        item
      ) =>
        total +
        getQuantity(item),
      0
    );


  cartItemLabel.textContent =
    `${count} ${
      count === 1
        ? "item"
        : "items"
    }`;

}


// =====================================
// RENDER
// =====================================

function renderCart() {

  updateHeader();


  if (!cart.length) {

    loadingState.style.display =
      "none";

    cartContent.style.display =
      "none";

    emptyState.style.display =
      "block";

    clearCartButton.style.display =
      "none";

    return;

  }


  loadingState.style.display =
    "none";

  emptyState.style.display =
    "none";

  cartContent.style.display =
    "block";

  clearCartButton.style.display =
    "inline-flex";


  cartItems.innerHTML = "";


  let totalQuantity = 0;

  let totalAmount = 0;


  cart.forEach(
    (
      item,
      index
    ) => {

      const data =
        getProductData(
          item
        );


      const quantity =
        getQuantity(
          item
        );


      const eachPrice =
        data.price;


      const itemTotal =
        eachPrice *
        quantity;


      totalQuantity +=
        quantity;


      totalAmount +=
        itemTotal;


      const outOfStock =
        data.product &&
        data.stock <= 0;


      const row =
        document.createElement(
          "div"
        );


      row.className =
        "cart-item";


      if (outOfStock) {

        row.classList.add(
          "unavailable"
        );

      }


      let imageHTML;


      if (
        data.image
      ) {

        imageHTML = `
          <img
            class="cart-product-img"
            src="${escapeHTML(
              data.image
            )}"
            alt="${escapeHTML(
              data.name
            )}"
          >
        `;

      } else {

        imageHTML = `
          <div class="cart-image-placeholder">
            
          </div>
        `;

      }


      row.innerHTML = `

        <div class="cart-product-image">
          ${imageHTML}
        </div>


        <div class="cart-product-info">

          <div class="cart-product-name">
            ${escapeHTML(
              data.name
            )}
          </div>


          ${
            item.variant
              ? `
                <div class="cart-product-variant">
                  ${escapeHTML(
                    item.variant
                  )}
                </div>
              `
              : ""
          }


          <div class="cart-product-price">
            ${formatMoney(
              eachPrice
            )}
          </div>


          ${
            outOfStock
              ? `
                <div class="cart-stock-error">
                  Out of stock
                </div>
              `
              : ""
          }


          <div class="cart-product-bottom">

            <div class="quantity-control">

              <button
                class="quantity-button decrease-button"
                type="button"
                data-index="${index}"
                ${
                  quantity <= 1
                    ? "disabled"
                    : ""
                }
              >
                ➖
              </button>


              <span class="quantity-value">
                ${quantity}
              </span>


              <button
                class="quantity-button increase-button"
                type="button"
                data-index="${index}"
                ${
                  data.product &&
                  quantity >= data.stock
                    ? "disabled"
                    : ""
                }
              >
                ➕
              </button>

            </div>


            <div class="cart-product-subtotal">
              ${formatMoney(
                itemTotal
              )}
            </div>

          </div>

        </div>


        <button
          class="remove-item-button"
          type="button"
          data-index="${index}"
        >
          Remove
        </button>

      `;


      cartItems.appendChild(
        row
      );

    }
  );


  selectedLabel.textContent =
    `${totalQuantity} ${
      totalQuantity === 1
        ? "item"
        : "items"
    }`;


  summaryItems.textContent =
    totalQuantity;


  summarySubtotal.textContent =
    formatMoney(
      totalAmount
    );


  summaryDelivery.textContent =
    "At checkout";


  summaryTotal.textContent =
    formatMoney(
      totalAmount
    );


  checkoutButton.disabled =
    totalQuantity === 0;


  setupItemButtons();

}


// =====================================
// ITEM BUTTONS
// =====================================

function setupItemButtons() {

  document
    .querySelectorAll(
      ".decrease-button"
    )
    .forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            changeQuantity(
              Number(
                button.dataset.index
              ),
              -1
            );

          }
        );

      }
    );


  document
    .querySelectorAll(
      ".increase-button"
    )
    .forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            changeQuantity(
              Number(
                button.dataset.index
              ),
              1
            );

          }
        );

      }
    );


  document
    .querySelectorAll(
      ".remove-item-button"
    )
    .forEach(
      button => {

        button.addEventListener(
          "click",
          () => {

            removeItem(
              Number(
                button.dataset.index
              )
            );

          }
        );

      }
    );

}


// =====================================
// QUANTITY
// =====================================

function changeQuantity(
  index,
  amount
) {

  const item =
    cart[index];


  if (!item) {
    return;
  }


  const data =
    getProductData(
      item
    );


  let quantity =
    getQuantity(
      item
    );


  quantity +=
    amount;


  if (
    quantity < 1
  ) {

    quantity = 1;

  }


  if (
    data.product &&
    data.stock > 0 &&
    quantity >
    data.stock
  ) {

    quantity =
      data.stock;

  }


  item.quantity =
    quantity;


  saveCart();

  renderCart();

}


// =====================================
// REMOVE ITEM
// =====================================

function removeItem(
  index
) {

  if (
    !cart[index]
  ) {
    return;
  }


  cart.splice(
    index,
    1
  );


  saveCart();

  renderCart();

  showToast(
    "Item removed from cart."
  );

}


// =====================================
// CHECKOUT
// =====================================

function proceedToCheckout() {

  if (!cart.length) {

    showToast(
      "Your cart is empty."
    );

    return;

  }


  localStorage.setItem(
    "marketHubCheckout",
    JSON.stringify(
      cart
    )
  );


  window.location.href =
    "checkout.html";

}


// =====================================
// CLEAR
// =====================================

function openClearConfirmation() {

  confirmOverlay.classList.add(
    "show"
  );

}


function closeClearConfirmation() {

  confirmOverlay.classList.remove(
    "show"
  );

}


function clearCart() {

  cart = [];

  products = [];


  saveCart();

  closeClearConfirmation();

  renderCart();

  showToast(
    "Cart cleared."
  );

}


// =====================================
// TOAST
// =====================================

function showToast(
  message
) {

  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  clearTimeout(
    toastTimer
  );


  toastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2200
    );

}


// =====================================
// NAVIGATION
// =====================================

function setupNavigation() {

  backButton.addEventListener(
    "click",
    () => {

      window.location.href =
        "index.html";

    }
  );

  shopNowButton.addEventListener(
    "click",
    () => {

      window.location.href =
        "index.html";

    }
  );


  continueShoppingButton.addEventListener(
    "click",
    () => {

      window.location.href =
        "index.html";

    }
  );


  checkoutButton.addEventListener(
    "click",
    proceedToCheckout
  );


  clearCartButton.addEventListener(
    "click",
    openClearConfirmation
  );


  cancelClearButton.addEventListener(
    "click",
    closeClearConfirmation
  );


  confirmClearButton.addEventListener(
    "click",
    clearCart
  );


  confirmOverlay.addEventListener(
    "click",
    event => {

      if (
        event.target ===
        confirmOverlay
      ) {

        closeClearConfirmation();

      }

    }
  );

}


// =====================================
// REFRESH
// =====================================

async function refreshCart() {

  loadCart();


  if (!cart.length) {

    products = [];

    renderCart();

    return;

  }


  try {

    await loadProducts();

  } catch (
    error
  ) {

    console.error(
      "Cart product refresh error:",
      error
    );

  }


  renderCart();

}


// =====================================
// SYNC
// =====================================

window.addEventListener(
  "storage",
  event => {

    if (
      event.key ===
      CART_KEY
    ) {

      refreshCart();

    }

  }
);


window.addEventListener(
  "marketHubCartUpdated",
  () => {

    refreshCart();

  }
);


window.addEventListener(
  "pageshow",
  () => {

    refreshCart();

  }
);


document.addEventListener(
  "visibilitychange",
  () => {

    if (
      document.visibilityState ===
      "visible"
    ) {

      refreshCart();

    }

  }
);


// =====================================
// START
// =====================================

async function initializeCart() {

  /*
    Check authentication before
    allowing access to the cart.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {
    return;
  }


  loadingState.style.display =
    "flex";


  setupNavigation();

  await refreshCart();

}


document.addEventListener(
  "DOMContentLoaded",
  initializeCart
);