const MARKET_HUB_HOME_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const MARKET_HUB_HOME_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const marketHubHomeSupabase =
  window.supabase.createClient(
    MARKET_HUB_HOME_URL,
    MARKET_HUB_HOME_KEY
  );


let marketHubSettings = null;


/* =========================================
   LOAD SETTINGS
========================================= */

async function loadMarketHubHomeSettings() {

  try {

    const {
      data,
      error
    } =
      await marketHubHomeSupabase
        .from("market_hub_public_settings")
        .select(`
          id,
          store_name,
          store_description,
          delivery_enabled,
          delivery_fee,
          free_delivery_threshold,
          delivery_areas,
          delivery_estimate,
          bank_transfer_enabled,
          cash_on_delivery_enabled,
          payment_instructions,
          minimum_order_amount,
          maintenance_mode,
          show_out_of_stock,
          customer_registration_enabled,
          require_email_confirmation,
          allow_customer_profile_edit,
          order_confirmation_message
        `)
        .eq("id", 1)
        .maybeSingle();


    if (error) {

      console.error(
        "MarketHub public settings error:",
        error
      );

      return;

    }


    if (!data) {

      console.warn(
        "No MarketHub public settings found."
      );

      return;

    }


    marketHubSettings = data;

    window.marketHubSettings = data;


    applyMarketHubSettings();


  } catch (error) {

    console.error(
      "Unable to load MarketHub public settings:",
      error
    );

  }

}


/* =========================================
   APPLY SETTINGS
========================================= */

function applyMarketHubSettings() {

  if (!marketHubSettings) {
    return;
  }


  updateStoreName();

  createAnnouncementTicker();

  updateStoreStatus();

  updateMaintenanceMode();

}


/* =========================================
   STORE NAME
========================================= */

function updateStoreName() {

  const storeName =
    marketHubSettings.store_name ||
    "MarketHub";


  document.title =
    storeName;


  const brandName =
    document.querySelector(
      ".brand-name"
    );


  if (brandName) {

    brandName.textContent =
      storeName;

  }

}


/* =========================================
   ANNOUNCEMENT TICKER
========================================= */

function createAnnouncementTicker() {

  const existing =
    document.getElementById(
      "marketHubAnnouncement"
    );


  if (existing) {
    existing.remove();
  }


  const storeName =
    marketHubSettings.store_name ||
    "MarketHub";


  const description =
    marketHubSettings.store_description ||
    "";


  const deliveryEstimate =
    marketHubSettings.delivery_estimate ||
    "";


  const deliveryAreas =
    marketHubSettings.delivery_areas ||
    "";


  const messages = [];


  messages.push(
    `Welcome to ${storeName}`
  );


  if (description) {

    messages.push(
      description
    );

  }


  if (
    marketHubSettings.delivery_enabled &&
    deliveryEstimate
  ) {

    messages.push(
      `Delivery: ${deliveryEstimate}`
    );

  }


  if (
    marketHubSettings.delivery_enabled &&
    deliveryAreas
  ) {

    messages.push(
      `Delivery Areas: ${deliveryAreas}`
    );

  }


  const message =
    messages.join(
      "   •   "
    );


  const ticker =
    document.createElement(
      "div"
    );


  ticker.id =
    "marketHubAnnouncement";

  ticker.className =
    "market-hub-announcement";


  ticker.innerHTML = `

    <div class="announcement-label">
      NEWS
    </div>

    <div class="announcement-window">

      <div class="announcement-track">

        <span>
          ${escapeHomeText(message)}
        </span>

        <span aria-hidden="true">
          ${escapeHomeText(message)}
        </span>

      </div>

    </div>

  `;


  const header =
    document.querySelector(
      ".main-header"
    );


  if (header) {

    header.insertAdjacentElement(
      "afterend",
      ticker
    );

  }


  injectAnnouncementStyles();

}


/* =========================================
   STORE STATUS
========================================= */

function updateStoreStatus() {

  const existing =
    document.getElementById(
      "marketHubStoreStatus"
    );


  if (existing) {
    existing.remove();
  }


  /*
    The public settings view does not expose
    store_status, so this section intentionally
    does nothing for now.
  */

  return;

}


/* =========================================
   MAINTENANCE MODE
========================================= */

function updateMaintenanceMode() {

  const existing =
    document.getElementById(
      "marketHubMaintenanceOverlay"
    );


  if (existing) {
    existing.remove();
  }


  if (
    !marketHubSettings.maintenance_mode
  ) {

    return;

  }


  const overlay =
    document.createElement(
      "div"
    );


  overlay.id =
    "marketHubMaintenanceOverlay";

  overlay.className =
    "market-hub-maintenance";


  const storeName =
    marketHubSettings.store_name ||
    "MarketHub";


  overlay.innerHTML = `

    <div class="maintenance-card">

      <div class="maintenance-logo">
        M
      </div>

      <h2>
        ${escapeHomeText(storeName)}
      </h2>

      <h3>
        We're temporarily unavailable
      </h3>

      <p>
        We're currently performing maintenance.
        Please check back shortly.
      </p>

    </div>

  `;


  document.body.appendChild(
    overlay
  );


  injectAnnouncementStyles();

}


/* =========================================
   TEXT ESCAPING
========================================= */

function escapeHomeText(
  value
) {

  return String(
    value ?? ""
  )
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    )
    .replace(
      /"/g,
      "&quot;"
    )
    .replace(
      /'/g,
      "&#039;"
    );

}


/* =========================================
   STYLES
========================================= */

function injectAnnouncementStyles() {

  if (
    document.getElementById(
      "marketHubAnnouncementStyles"
    )
  ) {

    return;

  }


  const style =
    document.createElement(
      "style"
    );


  style.id =
    "marketHubAnnouncementStyles";


  style.textContent = `

    .market-hub-announcement {

      width: 100%;

      height: 34px;

      display: flex;

      align-items: center;

      overflow: hidden;

      background: #e5484d;

      color: #ffffff;

      box-sizing: border-box;

    }


    .announcement-label {

      height: 100%;

      min-width: 52px;

      padding: 0 10px;

      display: flex;

      align-items: center;

      justify-content: center;

      background: #c92f35;

      color: #ffffff;

      font-size: 9px;

      font-weight: 900;

      letter-spacing: 0.7px;

      z-index: 2;

      flex-shrink: 0;

    }


    .announcement-window {

      flex: 1;

      height: 100%;

      overflow: hidden;

      position: relative;

    }


    .announcement-track {

      height: 100%;

      display: flex;

      align-items: center;

      width: max-content;

      white-space: nowrap;

      animation:
        marketHubNewsScroll
        28s
        linear
        infinite;

    }


    .announcement-track span {

      display: inline-block;

      padding-right: 90px;

      font-size: 13px;

      font-weight: 700;

      line-height: 34px;

    }


    @keyframes marketHubNewsScroll {

      0% {
        transform:
          translateX(0);
      }

      100% {
        transform:
          translateX(-50%);
      }

    }


    .market-hub-disabled-order {

      opacity: 0.5 !important;

      cursor: not-allowed !important;

    }


    .market-hub-maintenance {

      position: fixed;

      inset: 0;

      z-index: 99999;

      background:
        rgba(255,255,255,0.98);

      display: flex;

      align-items: center;

      justify-content: center;

      padding: 20px;

      box-sizing: border-box;

    }


    .maintenance-card {

      width: min(
        360px,
        100%
      );

      text-align: center;

    }


    .maintenance-logo {

      width: 58px;

      height: 58px;

      margin:
        0 auto 14px;

      border-radius: 16px;

      display: flex;

      align-items: center;

      justify-content: center;

      background: #ff7900;

      color: #ffffff;

      font-size: 25px;

      font-weight: 900;

    }


    .maintenance-card h2 {

      margin: 0;

      color: #171717;

      font-size: 21px;

    }


    .maintenance-card h3 {

      margin:
        16px 0 6px;

      color: #222222;

      font-size: 16px;

    }


    .maintenance-card p {

      margin:
        0 auto 17px;

      color: #777777;

      font-size: 12px;

      line-height: 1.5;

    }


    @media (
      max-width: 500px
    ) {

      .market-hub-announcement {

        height: 33px;

      }


      .announcement-label {

        min-width: 48px;

        padding:
          0 8px;

        font-size: 8px;

      }


      .announcement-track span {

        font-size: 12px;

        font-weight: 700;

        line-height: 33px;

        padding-right: 70px;

      }

    }

  `;


  document.head.appendChild(
    style
  );

}


/* =========================================
   START
========================================= */

document.addEventListener(
  "DOMContentLoaded",
  () => {

    loadMarketHubHomeSettings();

  }
);