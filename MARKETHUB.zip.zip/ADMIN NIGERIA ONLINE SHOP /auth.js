/* =========================================================
   MARKET HUB — AUTHENTICATION
   Login / Sign Up / Forgot Password / Reset Password
========================================================= */


/* =========================================================
   SUPABASE CONFIG
========================================================= */

const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const supabaseClient =
  supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =========================================================
   COMMON HELPERS
========================================================= */

function getElement(id) {
  return document.getElementById(id);
}


/* =========================================================
   TOAST
========================================================= */

function showToast(message) {

  const toast =
    getElement("authToast");

  if (!toast) {
    alert(message);
    return;
  }

  toast.textContent = message;

  toast.classList.add("show");

  clearTimeout(
    window.marketHubToastTimer
  );

  window.marketHubToastTimer =
    setTimeout(() => {

      toast.classList.remove("show");

    }, 3500);
}


/* =========================================================
   BUTTON LOADING
========================================================= */

function setButtonLoading(
  button,
  loading
) {

  if (!button) return;

  if (loading) {

    if (!button.dataset.originalText) {

      button.dataset.originalText =
        button.textContent;
    }

    button.disabled = true;

    button.classList.add(
      "auth-loading"
    );

  } else {

    button.disabled = false;

    button.classList.remove(
      "auth-loading"
    );

    if (button.dataset.originalText) {

      button.textContent =
        button.dataset.originalText;
    }
  }
}


/* =========================================================
   PASSWORD SHOW / HIDE
========================================================= */

function setupPasswordToggle(
  buttonId,
  inputId
) {

  const button =
    getElement(buttonId);

  const input =
    getElement(inputId);

  if (!button || !input) {
    return;
  }

  button.addEventListener(
    "click",
    () => {

      const isPassword =
        input.type === "password";

      input.type =
        isPassword
          ? "text"
          : "password";

      button.textContent =
        isPassword
          ? "Hide"
          : "Show";

      button.setAttribute(
        "aria-label",
        isPassword
          ? "Hide password"
          : "Show password"
      );

    }
  );
}


/* =========================================================
   LOAD CUSTOMER SETTINGS
========================================================= */

async function getCustomerSettings() {

  const {
    data,
    error
  } =
    await supabaseClient
      .from("market_hub_settings")
      .select(`
        customer_registration_enabled,
        require_email_confirmation
      `)
      .eq("id", 1)
      .maybeSingle();

  if (error) {

    console.error(
      "Customer settings error:",
      error
    );

    throw new Error(
      "Unable to check customer registration settings."
    );
  }

  return {

    customerRegistrationEnabled:
      data?.customer_registration_enabled !== false,

    requireEmailConfirmation:
      data?.require_email_confirmation === true

  };
}


/* =========================================================
   LOGIN
========================================================= */

async function handleLogin(event) {

  event.preventDefault();

  const emailInput =
    getElement("loginEmail");

  const passwordInput =
    getElement("loginPassword");

  const loginButton =
    getElement("loginButton");

  if (
    !emailInput ||
    !passwordInput
  ) {
    return;
  }

  const email =
    emailInput.value.trim();

  const password =
    passwordInput.value;


  /* -----------------------------------------
     VALIDATION
  ----------------------------------------- */

  if (!email) {

    showToast(
      "Please enter your email address."
    );

    emailInput.focus();

    return;
  }

  if (!password) {

    showToast(
      "Please enter your password."
    );

    passwordInput.focus();

    return;
  }


  setButtonLoading(
    loginButton,
    true
  );


  try {

    /* -----------------------------------------
       LOGIN
    ----------------------------------------- */

    const {
      data,
      error
    } =
      await supabaseClient.auth
        .signInWithPassword({
          email,
          password
        });

    if (error) {
      throw error;
    }

    if (
      !data ||
      !data.user
    ) {

      throw new Error(
        "Login could not be completed."
      );
    }


    /* -----------------------------------------
       CHECK EMAIL CONFIRMATION SETTING
    ----------------------------------------- */

    let settings = null;

    try {

      settings =
        await getCustomerSettings();

    } catch (settingsError) {

      console.error(
        "Unable to read customer settings:",
        settingsError
      );

      /*
        Do not block normal login if the settings
        table cannot be read here.
      */
    }


    /* -----------------------------------------
       EMAIL CONFIRMATION CHECK
    ----------------------------------------- */

    if (
      settings &&
      settings.requireEmailConfirmation &&
      !data.user.email_confirmed_at
    ) {

      await supabaseClient.auth.signOut();

      showToast(
        "Please confirm your email address before logging in."
      );

      setButtonLoading(
        loginButton,
        false
      );

      return;
    }


    /* -----------------------------------------
       SUCCESS
    ----------------------------------------- */

    window.location.href =
      "index.html";


  } catch (error) {

    console.error(
      "MarketHub login error:",
      error
    );

    let message =
      error.message ||
      "Unable to log in.";


    if (
      message
        .toLowerCase()
        .includes(
          "invalid login credentials"
        )
    ) {

      message =
        "Incorrect email or password.";
    }


    showToast(message);

    setButtonLoading(
      loginButton,
      false
    );
  }
}


/* =========================================================
   SIGN UP
========================================================= */

async function handleSignup(event) {

  event.preventDefault();


  /* -----------------------------------------
     ELEMENTS
  ----------------------------------------- */

  const fullNameInput =
    getElement("signupFullName");

  const emailInput =
    getElement("signupEmail");

  const phoneInput =
    getElement("signupPhone");

  const passwordInput =
    getElement("signupPassword");

  const confirmInput =
    getElement("signupConfirmPassword");

  const signupButton =
    getElement("signupButton");


  if (
    !fullNameInput ||
    !emailInput ||
    !passwordInput ||
    !confirmInput
  ) {
    return;
  }


  /* -----------------------------------------
     VALUES
  ----------------------------------------- */

  const fullName =
    fullNameInput.value.trim();

  const email =
    emailInput.value.trim();

  const phone =
    phoneInput
      ? phoneInput.value.trim()
      : "";

  const password =
    passwordInput.value;

  const confirmPassword =
    confirmInput.value;


  /* -----------------------------------------
     VALIDATION
  ----------------------------------------- */

  if (!fullName) {

    showToast(
      "Please enter your full name."
    );

    fullNameInput.focus();

    return;
  }

  if (!email) {

    showToast(
      "Please enter your email address."
    );

    emailInput.focus();

    return;
  }

  if (!password) {

    showToast(
      "Please create a password."
    );

    passwordInput.focus();

    return;
  }

  if (password.length < 6) {

    showToast(
      "Password must be at least 6 characters."
    );

    passwordInput.focus();

    return;
  }

  if (
    password !== confirmPassword
  ) {

    showToast(
      "Passwords do not match."
    );

    confirmInput.focus();

    return;
  }


  setButtonLoading(
    signupButton,
    true
  );


  try {

    /* -----------------------------------------
       CHECK ADMIN SETTINGS
    ----------------------------------------- */

    const settings =
      await getCustomerSettings();


    /* -----------------------------------------
       REGISTRATION DISABLED
    ----------------------------------------- */

    if (
      !settings.customerRegistrationEnabled
    ) {

      showToast(
        "Customer registration is currently closed."
      );

      setButtonLoading(
        signupButton,
        false
      );

      return;
    }


    /* -----------------------------------------
       CREATE ACCOUNT
    ----------------------------------------- */

    const {
      data,
      error
    } =
      await supabaseClient.auth.signUp({

        email,

        password,

        options: {

          data: {

            full_name:
              fullName,

            phone:
              phone || ""

          }
        }
      });


    if (error) {
      throw error;
    }


    if (
      !data ||
      !data.user
    ) {

      throw new Error(
        "Account creation failed."
      );
    }


    /* -----------------------------------------
       CREATE PROFILE
    ----------------------------------------- */

    const {
      error: profileError
    } =
      await supabaseClient
        .from("profiles")
        .upsert(
          {

            id:
              data.user.id,

            full_name:
              fullName,

            email:
              email,

            phone:
              phone || null,

            avatar_url:
              null,

            updated_at:
              new Date().toISOString()

          },
          {
            onConflict: "id"
          }
        );


    if (profileError) {

      console.error(
        "Profile creation warning:",
        profileError
      );
    }


    /* -----------------------------------------
       ACCOUNT CREATED + SESSION
    ----------------------------------------- */

    if (data.session) {

      /*
        If Admin Settings requires email
        confirmation, verify it here.
      */

      if (
        settings.requireEmailConfirmation &&
        !data.user.email_confirmed_at
      ) {

        await supabaseClient.auth.signOut();

        showToast(
          "Account created. Please confirm your email before logging in."
        );

        setTimeout(() => {

          window.location.href =
            "login.html";

        }, 2500);

        return;
      }


      window.location.href =
        "index.html";

      return;
    }


    /* -----------------------------------------
       ACCOUNT CREATED WITHOUT SESSION
       Usually means email confirmation
       is required by Supabase Auth.
    ----------------------------------------- */

    showToast(
      "Account created. Check your email to confirm your account."
    );


    setTimeout(() => {

      window.location.href =
        "login.html";

    }, 2500);


  } catch (error) {

    console.error(
      "MarketHub signup error:",
      error
    );


    let message =
      error.message ||
      "Unable to create your account.";


    if (
      message
        .toLowerCase()
        .includes(
          "already registered"
        )
    ) {

      message =
        "An account with this email already exists.";
    }


    showToast(message);


    setButtonLoading(
      signupButton,
      false
    );
  }
}


/* =========================================================
   FORGOT PASSWORD
========================================================= */

async function handleForgotPassword(
  event
) {

  event.preventDefault();


  const emailInput =
    getElement("forgotEmail");

  const button =
    getElement("forgotPasswordButton");


  if (!emailInput) {
    return;
  }


  const email =
    emailInput.value.trim();


  if (!email) {

    showToast(
      "Please enter your email address."
    );

    emailInput.focus();

    return;
  }


  setButtonLoading(
    button,
    true
  );


  try {

    const redirectUrl =
      window.location.origin +
      window.location.pathname
        .replace(
          /[^/]*$/,
          "reset-password.html"
        );


    const {
      error
    } =
      await supabaseClient.auth
        .resetPasswordForEmail(
          email,
          {
            redirectTo:
              redirectUrl
          }
        );


    if (error) {
      throw error;
    }


    showToast(
      "If an account exists for that email, a password reset link has been sent."
    );


    emailInput.value = "";


  } catch (error) {

    console.error(
      "MarketHub forgot password error:",
      error
    );


    showToast(
      error.message ||
      "Unable to send the password reset email."
    );


  } finally {

    setButtonLoading(
      button,
      false
    );
  }
}


/* =========================================================
   RESET PASSWORD
========================================================= */

async function handleResetPassword(
  event
) {

  event.preventDefault();


  const passwordInput =
    getElement("resetPassword");

  const confirmInput =
    getElement("resetConfirmPassword");

  const button =
    getElement("resetPasswordButton");


  if (
    !passwordInput ||
    !confirmInput
  ) {
    return;
  }


  const password =
    passwordInput.value;

  const confirmPassword =
    confirmInput.value;


  if (!password) {

    showToast(
      "Please enter your new password."
    );

    passwordInput.focus();

    return;
  }


  if (password.length < 6) {

    showToast(
      "Password must be at least 6 characters."
    );

    passwordInput.focus();

    return;
  }


  if (
    password !== confirmPassword
  ) {

    showToast(
      "Passwords do not match."
    );

    confirmInput.focus();

    return;
  }


  setButtonLoading(
    button,
    true
  );


  try {

    const {
      error
    } =
      await supabaseClient.auth
        .updateUser({
          password
        });


    if (error) {
      throw error;
    }


    showToast(
      "Password updated successfully."
    );


    setTimeout(
      async () => {

        await supabaseClient.auth.signOut();

        window.location.href =
          "login.html";

      },
      1800
    );


  } catch (error) {

    console.error(
      "MarketHub password reset error:",
      error
    );


    showToast(
      error.message ||
      "Unable to update your password."
    );


    setButtonLoading(
      button,
      false
    );
  }
}


/* =========================================================
   LOGOUT
========================================================= */

async function logoutUser() {

  try {

    await supabaseClient.auth.signOut();

  } catch (error) {

    console.error(
      "MarketHub logout error:",
      error
    );

  } finally {

    window.location.href =
      "login.html";
  }
}


/* =========================================================
   TERMS / PRIVACY
========================================================= */

function setupLegalLinks() {

  const termsLink =
    getElement("termsLink");

  const privacyLink =
    getElement("privacyLink");


  if (termsLink) {

    termsLink.addEventListener(
      "click",
      (event) => {

        event.preventDefault();

        showToast(
          "Terms & Conditions will be available here."
        );
      }
    );
  }


  if (privacyLink) {

    privacyLink.addEventListener(
      "click",
      (event) => {

        event.preventDefault();

        showToast(
          "Privacy Policy will be available here."
        );
      }
    );
  }
}


/* =========================================================
   PAGE INITIALIZATION
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  () => {


    /* -----------------------------------------
       LOGIN
    ----------------------------------------- */

    const loginForm =
      getElement("loginForm");

    if (loginForm) {

      loginForm.addEventListener(
        "submit",
        handleLogin
      );
    }


    setupPasswordToggle(
      "toggleLoginPassword",
      "loginPassword"
    );


    /* -----------------------------------------
       SIGN UP
    ----------------------------------------- */

    const signupForm =
      getElement("signupForm");

    if (signupForm) {

      signupForm.addEventListener(
        "submit",
        handleSignup
      );
    }


    setupPasswordToggle(
      "toggleSignupPassword",
      "signupPassword"
    );


    setupPasswordToggle(
      "toggleSignupConfirmPassword",
      "signupConfirmPassword"
    );


    /* -----------------------------------------
       FORGOT PASSWORD
    ----------------------------------------- */

    const forgotForm =
      getElement("forgotPasswordForm");

    if (forgotForm) {

      forgotForm.addEventListener(
        "submit",
        handleForgotPassword
      );
    }


    /* -----------------------------------------
       RESET PASSWORD
    ----------------------------------------- */

    const resetForm =
      getElement("resetPasswordForm");

    if (resetForm) {

      resetForm.addEventListener(
        "submit",
        handleResetPassword
      );
    }


    setupPasswordToggle(
      "toggleResetPassword",
      "resetPassword"
    );


    setupPasswordToggle(
      "toggleResetConfirmPassword",
      "resetConfirmPassword"
    );


    /* -----------------------------------------
       LEGAL LINKS
    ----------------------------------------- */

    setupLegalLinks();

  }
);