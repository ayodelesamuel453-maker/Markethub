const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";


const {
  createClient
} = supabase;


const db =
  createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =========================
   AUTHENTICATION GUARD
========================= */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await db.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "welcome.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "welcome.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "welcome.html"
    );

    return false;
  }
}


/* =========================
   CONSTANTS
========================= */

const CART_KEY =
  "marketHubCart";

const PRODUCTS_PER_PAGE =
  12;


/*
  Banner automatically changes
  every 3 seconds.
*/

const BANNER_INTERVAL =
  3000;


/* =========================
   STATE
========================= */

let allProducts = [];

let filteredProducts = [];

let categories = [];

let currentCategory =
  "all";

let currentSearch =
  "";

let displayedCount =
  PRODUCTS_PER_PAGE;


/*
  Controls whether products
  with stock = 0 are shown.

  Default is true so the Home page
  continues showing products if the
  settings table cannot be loaded.
*/

let showOutOfStockProducts =
  true;


let banners = [];

let currentBannerIndex =
  0;

let bannerTimer =
  null;


/* =========================
   ELEMENTS
========================= */

const categoryList =
  document.getElementById(
    "categoryList"
  );

const bannerContainer =
  document.getElementById(
    "bannerContainer"
  );

const bannerDots =
  document.getElementById(
    "bannerDots"
  );

const productsGrid =
  document.getElementById(
    "productsGrid"
  );

const productCount =
  document.getElementById(
    "productCount"
  );

const loadMoreButton =
  document.getElementById(
    "loadMoreButton"
  );

const searchInput =
  document.getElementById(
    "searchInput"
  );

const clearSearchButton =
  document.getElementById(
    "clearSearchButton"
  );


const headerCartButton =
  document.getElementById(
    "headerCartButton"
  );

const headerCartBadge =
  document.getElementById(
    "headerCartBadge"
  );

const bottomCartBadge =
  document.getElementById(
    "bottomCartBadge"
  );


/*
  Notification button.

  The old notification popup elements
  are intentionally not used anymore.
*/

const notificationButton =
  document.getElementById(
    "notificationButton"
  );

const notificationDot =
  document.getElementById(
    "notificationDot"
  );


const homeNav =
  document.getElementById(
    "homeNav"
  );

const cartNav =
  document.getElementById(
    "cartNav"
  );

const ordersNav =
  document.getElementById(
    "ordersNav"
  );

const profileNav =
  document.getElementById(
    "profileNav"
  );


const toast =
  document.getElementById(
    "toast"
  );


/* =========================
   START
========================= */

document.addEventListener(
  "DOMContentLoaded",
  initializeHome
);


async function initializeHome() {

  /*
    Check authentication before
    loading any customer shopping data.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {
    return;
  }


  updateCartBadge();

  setupNavigation();

  setupSearch();

  setupNotifications();


  await Promise.all([
    loadHomeSettings(),
    loadCategories(),
    loadBanners(),
    loadProducts()
  ]);


  loadNotificationStatus();
}

/* =========================
   HOME SETTINGS
========================= */

async function loadHomeSettings() {

  try {

    const {
      data,
      error
    } = await db
      .from("market_hub_public_settings")
      .select(
        "show_out_of_stock"
      )
      .eq(
        "id",
        1
      )
      .maybeSingle();


    if (error) {
      throw error;
    }


    /*
      If the public settings view
      contains the setting, use it.

      Otherwise keep the default
      of true.
    */

    if (data) {

      showOutOfStockProducts =
        data.show_out_of_stock !== false;

    } else {

      showOutOfStockProducts =
        true;

    }


  } catch (error) {

    console.error(
      "HOME SETTINGS ERROR:",
      error
    );


    /*
      Keep products visible if
      settings cannot be loaded.
    */

    showOutOfStockProducts =
      true;

  }

}


/* =========================
   CATEGORIES
========================= */

async function loadCategories() {

  try {

    const {
      data,
      error
    } = await db
      .from("categories")
      .select(
        "id, name, sort_order, status"
      )
      .eq(
        "status",
        "active"
      )
      .order(
        "sort_order",
        {
          ascending: true
        }
      );


    if (error) {
      throw error;
    }


    categories =
      data || [];


    renderCategories();


  } catch (error) {

    console.error(
      "CATEGORY ERROR:",
      error
    );


    /*
      Keep All available even if
      categories cannot be loaded.
    */

    renderCategories();
  }
}


/* =========================
   RENDER CATEGORIES
========================= */

function renderCategories() {

  categoryList.innerHTML = "";


  const allButton =
    document.createElement(
      "button"
    );


  allButton.className =
    "category-chip active";

  allButton.type =
    "button";

  allButton.dataset.category =
    "all";

  allButton.textContent =
    "All";


  allButton.addEventListener(
    "click",
    () => {

      selectCategory(
        "all"
      );

    }
  );


  categoryList.appendChild(
    allButton
  );


  categories.forEach(
    category => {

      const button =
        document.createElement(
          "button"
        );


      button.className =
        "category-chip";

      button.type =
        "button";

      button.dataset.category =
        category.name;

      button.textContent =
        category.name;


      button.addEventListener(
        "click",
        () => {

          selectCategory(
            category.name
          );

        }
      );


      categoryList.appendChild(
        button
      );

    }
  );
}


/* =========================
   SELECT CATEGORY
========================= */

function selectCategory(
  category
) {

  currentCategory =
    category;

  displayedCount =
    PRODUCTS_PER_PAGE;


  document
    .querySelectorAll(
      ".category-chip"
    )
    .forEach(button => {

      button.classList.toggle(
        "active",
        button.dataset.category ===
          category
      );

    });


  applyFilters();
}


/* =========================
   BANNERS
========================= */

async function loadBanners() {

  try {

    const {
      data,
      error
    } = await db
      .from("banners")
      .select(
        "id, image, title, text, button, link, status, sort_order"
      )
      .eq(
        "status",
        "active"
      )
      .order(
        "sort_order",
        {
          ascending: true
        }
      );


    if (error) {
      throw error;
    }


    banners =
      data || [];


    renderBanners();


  } catch (error) {

    console.error(
      "BANNER ERROR:",
      error
    );


    bannerContainer.innerHTML =
      `
        <div class="banner-loading">
          No banners available.
        </div>
      `;

    bannerDots.innerHTML =
      "";

  }
}


/* =========================
   RENDER BANNERS
========================= */

function renderBanners() {

  stopBannerTimer();


  if (!banners.length) {

    bannerContainer.innerHTML =
      `
        <div class="banner-loading">
          No banners available.
        </div>
      `;

    bannerDots.innerHTML =
      "";

    return;
  }


  bannerContainer.innerHTML =
    "";

  bannerDots.innerHTML =
    "";


  banners.forEach(
    (banner, index) => {

      const slide =
        document.createElement(
          "div"
        );


      slide.className =
        "banner-slide";


      if (index === 0) {

        slide.classList.add(
          "active"
        );

      }


      const image =
        document.createElement(
          "img"
        );


      image.src =
        banner.image || "";

      image.alt =
        banner.title ||
        "MarketHub banner";


      image.loading =
        index === 0
          ? "eager"
          : "lazy";


      slide.appendChild(
        image
      );


      const hasText =
        banner.title ||
        banner.text ||
        banner.button;


      if (hasText) {

        const overlay =
          document.createElement(
            "div"
          );


        overlay.className =
          "banner-overlay";


        if (banner.title) {

          const title =
            document.createElement(
              "div"
            );


          title.className =
            "banner-title";

          title.textContent =
            banner.title;


          overlay.appendChild(
            title
          );

        }


        if (banner.text) {

          const text =
            document.createElement(
              "div"
            );


          text.className =
            "banner-text";

          text.textContent =
            banner.text;


          overlay.appendChild(
            text
          );

        }


        if (
          banner.button &&
          banner.link
        ) {

          const button =
            document.createElement(
              "button"
            );


          button.className =
            "banner-button";

          button.type =
            "button";

          button.textContent =
            banner.button;


          button.addEventListener(
            "click",
            event => {

              event.stopPropagation();


              window.location.href =
                banner.link;

            }
          );


          overlay.appendChild(
            button
          );

        }


        slide.appendChild(
          overlay
        );

      }


      if (banner.link) {

        slide.style.cursor =
          "pointer";


        slide.addEventListener(
          "click",
          () => {

            window.location.href =
              banner.link;

          }
        );

      }


      bannerContainer.appendChild(
        slide
      );


      const dot =
        document.createElement(
          "span"
        );


      dot.className =
        "banner-dot";


      if (index === 0) {

        dot.classList.add(
          "active"
        );

      }


      dot.addEventListener(
        "click",
        () => {

          showBanner(
            index
          );

        }
      );


      bannerDots.appendChild(
        dot
      );

    }
  );


  currentBannerIndex =
    0;


  if (banners.length > 1) {

    startBannerTimer();

  }
}


/* =========================
   SHOW BANNER
========================= */

function showBanner(
  index
) {

  const slides =
    document.querySelectorAll(
      ".banner-slide"
    );

  const dots =
    document.querySelectorAll(
      ".banner-dot"
    );


  if (!slides.length) {
    return;
  }


  currentBannerIndex =
    index;


  slides.forEach(
    (slide, slideIndex) => {

      slide.classList.toggle(
        "active",
        slideIndex === index
      );

    }
  );


  dots.forEach(
    (dot, dotIndex) => {

      dot.classList.toggle(
        "active",
        dotIndex === index
      );

    }
  );
}


/* =========================
   BANNER TIMER
========================= */

function startBannerTimer() {

  stopBannerTimer();


  bannerTimer =
    setInterval(
      () => {

        if (
          !banners.length
        ) {
          return;
        }


        const next =
          (
            currentBannerIndex +
            1
          ) %
          banners.length;


        showBanner(
          next
        );

      },
      BANNER_INTERVAL
    );
}


function stopBannerTimer() {

  if (bannerTimer) {

    clearInterval(
      bannerTimer
    );

    bannerTimer =
      null;
  }
}


/* =========================
   PRODUCTS
========================= */

async function loadProducts() {

  productsGrid.innerHTML =
    `
      <div class="products-loading">
        Loading products...
      </div>
    `;


  try {

    const {
      data,
      error
    } = await db
      .from("products")
      .select("*")
      .eq(
        "status",
        "active"
      )
      .order(
        "created_at",
        {
          ascending: false
        }
      );


    if (error) {
      throw error;
    }


    allProducts =
      data || [];


    applyFilters();


  } catch (error) {

    console.error(
      "PRODUCT ERROR:",
      error
    );


    productsGrid.innerHTML =
      `
        <div class="products-empty">
          Unable to load products.
        </div>
      `;


    productCount.textContent =
      "0 items";
  }
}


/* =========================
   FILTERS
========================= */

function applyFilters() {

  const search =
    currentSearch
      .trim()
      .toLowerCase();


  filteredProducts =
    allProducts.filter(
      product => {

        /*
          OUT-OF-STOCK SETTING

          If Show Out-of-Stock Products
          is OFF, remove products whose
          stock is 0 or below.

          If it is ON, keep them.
        */

        const stockNumber =
          Number(
            product.stock || 0
          );


        const stockMatch =
          showOutOfStockProducts ||
          stockNumber > 0;


        if (!stockMatch) {
          return false;
        }


        const categoryMatch =
          currentCategory ===
            "all" ||
          String(
            product.category || ""
          ).toLowerCase() ===
            currentCategory.toLowerCase();


        const searchMatch =
          !search ||
          String(
            product.name || ""
          )
            .toLowerCase()
            .includes(search) ||

          String(
            product.category || ""
          )
            .toLowerCase()
            .includes(search) ||

          String(
            product.description || ""
          )
            .toLowerCase()
            .includes(search);


        return (
          categoryMatch &&
          searchMatch
        );

      }
    );


  renderProducts();
}


/* =========================
   RENDER PRODUCTS
========================= */

function renderProducts() {

  const visibleProducts =
    filteredProducts.slice(
      0,
      displayedCount
    );


  productCount.textContent =
    `${filteredProducts.length} ${
      filteredProducts.length === 1
        ? "item"
        : "items"
    }`;


  if (!visibleProducts.length) {

    productsGrid.innerHTML =
      `
        <div class="products-empty">
          No products found.
        </div>
      `;


    loadMoreButton.classList.remove(
      "show"
    );


    return;
  }


  productsGrid.innerHTML =
    "";


  visibleProducts.forEach(
    product => {

      productsGrid.appendChild(
        createProductCard(
          product
        )
      );

    }
  );


  if (
    displayedCount <
    filteredProducts.length
  ) {

    loadMoreButton.classList.add(
      "show"
    );

  } else {

    loadMoreButton.classList.remove(
      "show"
    );

  }
}


/* =========================
   PRODUCT CARD
========================= */

function createProductCard(
  product
) {

  const card =
    document.createElement(
      "article"
    );


  card.className =
    "product-card";


  card.addEventListener(
    "click",
    () => {

      window.location.href =
        `product.html?id=${encodeURIComponent(
          product.id
        )}`;

    }
  );


  const imageWrap =
    document.createElement(
      "div"
    );


  imageWrap.className =
    "product-image-wrap";


  const image =
    document.createElement(
      "img"
    );


  image.className =
    "product-image";


  image.alt =
    product.name ||
    "Product";


  image.loading =
    "lazy";


  const productImage =
    getProductImage(
      product
    );


  if (productImage) {

    image.src =
      productImage;

  } else {

    image.src =
      "data:image/svg+xml;charset=UTF-8," +
      encodeURIComponent(
        `
          <svg xmlns="http://www.w3.org/2000/svg"
               width="600"
               height="600"
               viewBox="0 0 600 600">

            <rect
              width="600"
              height="600"
              fill="#eeeeee"
            />

            <text
              x="300"
              y="300"
              text-anchor="middle"
              dominant-baseline="middle"
              font-family="Arial"
              font-size="32"
              fill="#999999"
            >
              MarketHub
            </text>

          </svg>
        `
      );

  }


  imageWrap.appendChild(
    image
  );


  if (
    Number(product.discount) > 0
  ) {

    const discount =
      document.createElement(
        "span"
      );


    discount.className =
      "discount-badge";


    discount.textContent =
      `-${Number(
        product.discount
      )}%`;


    imageWrap.appendChild(
      discount
    );

  }


  if (
    product.flash_sale === true
  ) {

    const flash =
      document.createElement(
        "span"
      );


    flash.className =
      "flash-badge";


    flash.textContent =
      "FLASH";


    imageWrap.appendChild(
      flash
    );

  }


  const info =
    document.createElement(
      "div"
    );


  info.className =
    "product-info";


  const name =
    document.createElement(
      "div"
    );


  name.className =
    "product-name";


  name.textContent =
    product.name ||
    "Unnamed Product";


  const priceRow =
    document.createElement(
      "div"
    );


  priceRow.className =
    "product-price-row";


  const currentPrice =
    getCurrentPrice(
      product
    );


  const price =
    document.createElement(
      "span"
    );


  price.className =
    "product-price";


  price.textContent =
    formatNaira(
      currentPrice
    );


  priceRow.appendChild(
    price
  );


  const oldPrice =
    getOldPrice(
      product
    );


  if (
    oldPrice > currentPrice
  ) {

    const old =
      document.createElement(
        "span"
      );


    old.className =
      "product-old-price";


    old.textContent =
      formatNaira(
        oldPrice
      );


    priceRow.appendChild(
      old
    );

  }


  const category =
    document.createElement(
      "div"
    );


  category.className =
    "product-category";


  category.textContent =
    product.category ||
    "General";


  const stock =
    document.createElement(
      "div"
    );


  const stockNumber =
    Number(
      product.stock || 0
    );


  stock.className =
    "product-stock";


  if (
    stockNumber <= 0
  ) {

    stock.classList.add(
      "out"
    );


    stock.textContent =
      "Out of stock";

  } else {

    stock.textContent =
      `${stockNumber} in stock`;

  }


  info.appendChild(
    name
  );

  info.appendChild(
    priceRow
  );

  info.appendChild(
    category
  );

  info.appendChild(
    stock
  );


  card.appendChild(
    imageWrap
  );

  card.appendChild(
    info
  );


  return card;
}


/* =========================
   PRODUCT IMAGE
========================= */

function getProductImage(
  product
) {

  const images =
    product.images;


  if (
    Array.isArray(images) &&
    images.length
  ) {

    const first =
      images[0];


    if (
      typeof first ===
      "string"
    ) {

      return first;

    }


    if (
      first &&
      typeof first ===
      "object"
    ) {

      return (
        first.url ||
        first.image_url ||
        first.src ||
        ""
      );

    }

  }


  if (
    typeof images ===
    "string"
  ) {

    try {

      const parsed =
        JSON.parse(
          images
        );


      if (
        Array.isArray(parsed) &&
        parsed.length
      ) {

        return typeof parsed[0] ===
          "string"
          ? parsed[0]
          : (
              parsed[0]?.url ||
              parsed[0]?.image_url ||
              parsed[0]?.src ||
              ""
            );

      }

    } catch (error) {

      return images;

    }

  }


  return "";
}


/* =========================
   PRICE
========================= */

function getCurrentPrice(
  product
) {

  if (
    product.flash_sale === true &&
    Number(product.flash_price) > 0
  ) {

    return Number(
      product.flash_price
    );

  }


  return Number(
    product.price || 0
  );
}


function getOldPrice(
  product
) {

  return Number(
    product.old_price || 0
  );
}


/* =========================
   NAIRA
========================= */

function formatNaira(
  amount
) {

  return new Intl.NumberFormat(
    "en-NG",
    {
      style: "currency",
      currency: "NGN",
      maximumFractionDigits: 0
    }
  ).format(
    Number(amount) || 0
  );
}


/* =========================
   LOAD MORE
========================= */

loadMoreButton.addEventListener(
  "click",
  () => {

    displayedCount +=
      PRODUCTS_PER_PAGE;


    renderProducts();

  }
);


/* =========================
   SEARCH
========================= */

function setupSearch() {

  searchInput.addEventListener(
    "input",
    () => {

      currentSearch =
        searchInput.value;


      clearSearchButton.style.display =
        currentSearch
          ? "flex"
          : "none";


      displayedCount =
        PRODUCTS_PER_PAGE;


      applyFilters();

    }
  );


  clearSearchButton.addEventListener(
    "click",
    () => {

      searchInput.value =
        "";


      currentSearch =
        "";


      clearSearchButton.style.display =
        "none";


      displayedCount =
        PRODUCTS_PER_PAGE;


      applyFilters();


      searchInput.focus();

    }
  );
}


/* =========================
   CART BADGE
========================= */

function updateCartBadge() {

  let cart = [];


  try {

    cart =
      JSON.parse(
        localStorage.getItem(
          CART_KEY
        )
      ) || [];

  } catch (error) {

    cart = [];

  }


  const count =
    cart.reduce(
      (
        total,
        item
      ) => {

        return total +
          Number(
            item.quantity || 0
          );

      },
      0
    );


  headerCartBadge.textContent =
    count > 99
      ? "99+"
      : count;


  bottomCartBadge.textContent =
    count > 99
      ? "99+"
      : count;


  headerCartBadge.style.display =
    count > 0
      ? "flex"
      : "none";


  bottomCartBadge.style.display =
    count > 0
      ? "flex"
      : "none";
}


/* =========================
   NAVIGATION
========================= */

function setupNavigation() {

  headerCartButton.addEventListener(
    "click",
    () => {

      window.location.href =
        "cart.html";

    }
  );


  homeNav.addEventListener(
    "click",
    () => {

      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });

    }
  );


  cartNav.addEventListener(
    "click",
    () => {

      window.location.href =
        "cart.html";

    }
  );


  ordersNav.addEventListener(
    "click",
    () => {

      window.location.href =
        "orders.html";

    }
  );


  profileNav.addEventListener(
    "click",
    () => {

      window.location.href =
        "profile.html";

    }
  );
}


/* =========================
   NOTIFICATIONS
========================= */

/*
  The Home notification button
  now goes directly to the
  dedicated customer notification
  page.

  The old notification popup
  is no longer used.
*/

function setupNotifications() {

  if (!notificationButton) {
    return;
  }


  notificationButton.addEventListener(
    "click",
    () => {

      window.location.href =
        "customer-notifications.html";

    }
  );
}


/* =========================
   CUSTOMER NOTIFICATION STATUS
========================= */

/*
  Checks whether the signed-in
  customer has unread notifications.

  This only controls the small
  notification dot on the Home
  page.

  It does NOT open a popup.
*/

async function loadNotificationStatus() {

  if (!notificationDot) {
    return;
  }


  try {

    const {
      data: {
        user
      }
    } = await db.auth.getUser();


    if (!user) {

      notificationDot.classList.remove(
        "show"
      );

      return;
    }


    const {
      count,
      error
    } = await db
      .from("customer_notifications")
      .select(
        "id",
        {
          count: "exact",
          head: true
        }
      )
      .eq(
        "customer_id",
        user.id
      )
      .eq(
        "is_read",
        false
      );


    if (error) {

      console.error(
        "CUSTOMER NOTIFICATION STATUS ERROR:",
        error
      );


      notificationDot.classList.remove(
        "show"
      );

      return;
    }


    if (
      Number(count || 0) > 0
    ) {

      notificationDot.classList.add(
        "show"
      );

    } else {

      notificationDot.classList.remove(
        "show"
      );

    }


  } catch (error) {

    console.error(
      "NOTIFICATION STATUS ERROR:",
      error
    );


    notificationDot.classList.remove(
      "show"
    );

  }

}


/* =========================
   TOAST
========================= */

let toastTimer =
  null;


function showToast(
  message
) {

  if (!toast) {
    return;
  }


  clearTimeout(
    toastTimer
  );


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  toastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2600
    );
}


/* =========================
   CART SYNC
========================= */

window.addEventListener(
  "storage",
  event => {

    if (
      event.key ===
      CART_KEY
    ) {

      updateCartBadge();

    }

  }
);


document.addEventListener(
  "visibilitychange",
  () => {

    if (
      document.visibilityState ===
      "visible"
    ) {

      updateCartBadge();

      loadNotificationStatus();

    }

  }
);