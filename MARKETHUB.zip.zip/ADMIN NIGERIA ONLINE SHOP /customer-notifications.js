const SUPABASE_URL =
"https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
"sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const marketHubCustomer =
window.supabase.createClient(
SUPABASE_URL,
SUPABASE_ANON_KEY
);

/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } =
      await marketHubCustomer.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


/* =========================================================
STATE
========================================================= */

let allNotifications = [];

let currentFilter = "all";

let currentUser = null;

/* =========================================================
ELEMENTS
========================================================= */

const notificationList =
document.getElementById(
"notificationList"
);

const notificationsLoading =
document.getElementById(
"notificationsLoading"
);

const notificationsEmpty =
document.getElementById(
"notificationsEmpty"
);

const notificationsError =
document.getElementById(
"notificationsError"
);

const notificationsErrorText =
document.getElementById(
"notificationsErrorText"
);

const retryButton =
document.getElementById(
"retryButton"
);

const markAllButton =
document.getElementById(
"markAllButton"
);

const backButton =
document.getElementById(
"backButton"
);

const toast =
document.getElementById(
"notificationToast"
);

const filterButtons =
document.querySelectorAll(
".filter-button"
);

/* =========================================================
INITIALIZE
========================================================= */

document.addEventListener(
"DOMContentLoaded",
initialize
);

async function initialize() {

  setupButtons();


  /*
    Check authentication before
    loading customer notifications.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {

    return;

  }


  await loadCurrentUser();

}

/* =========================================================
BUTTONS
========================================================= */

function setupButtons() {

if (backButton) {

backButton.addEventListener(
  "click",
  () => {

    window.location.href =
      "index.html";

  }
);

}

if (retryButton) {

retryButton.addEventListener(
  "click",
  () => {

    loadNotifications();

  }
);

}

if (markAllButton) {

markAllButton.addEventListener(
  "click",
  markAllAsRead
);

}

filterButtons.forEach(
button => {

  button.addEventListener(
    "click",
    () => {

      currentFilter =
        button.dataset.filter ||
        "all";

      filterButtons.forEach(
        item => {

          item.classList.toggle(
            "active",
            item === button
          );

        }
      );

      renderNotifications();

    }
  );

}

);

}

/* =========================================================
CURRENT USER
========================================================= */

async function loadCurrentUser() {

showLoading();

hideError();

const {
data,
error
} =
await marketHubCustomer
.auth
.getUser();

if (error) {

showError(
  error.message ||
  "Unable to verify your account."
);

return;

}

currentUser =
data?.user || null;

if (!currentUser) {

window.location.href =
  "login.html";

return;

}

await loadNotifications();

}

/* =========================================================
LOAD NOTIFICATIONS
========================================================= */

async function loadNotifications() {

if (!currentUser) {
return;
}

showLoading();

hideError();

const {
data,
error
} =
await marketHubCustomer
.from(
"customer_notifications"
)
.select(
"id, customer_id, type, title, message, related_order_id, is_read, created_at"
)
.eq(
"customer_id",
currentUser.id
)
.order(
"created_at",
{
ascending: false
}
);

if (error) {

showError(
  error.message ||
  "Unable to load notifications."
);

return;

}

allNotifications =
data || [];

hideLoading();

renderNotifications();

}

/* =========================================================
RENDER
========================================================= */

function renderNotifications() {

if (!notificationList) {
return;
}

const visibleNotifications =
getVisibleNotifications();

notificationList.innerHTML = "";

if (
visibleNotifications.length === 0
) {

notificationList.style.display =
  "none";

notificationsEmpty.classList.add(
  "show"
);

updateMarkAllButton();

return;

}

notificationList.style.display =
"flex";

notificationsEmpty.classList.remove(
"show"
);

visibleNotifications.forEach(
notification => {

  notificationList.appendChild(
    createNotificationCard(
      notification
    )
  );

}

);

updateMarkAllButton();

}

/* =========================================================
FILTER
========================================================= */

function getVisibleNotifications() {

if (
currentFilter ===
"unread"
) {

return allNotifications.filter(
  notification =>
    !notification.is_read
);

}

return allNotifications;

}

/* =========================================================
CREATE CARD
========================================================= */

function createNotificationCard(
notification
) {

const card =
document.createElement(
"article"
);

card.className =
"notification-card";

if (!notification.is_read) {

card.classList.add(
  "unread"
);

}

const icon =
document.createElement(
"div"
);

icon.className =
"notification-icon ${getNotificationClass( notification.type )}";

icon.textContent =
getNotificationIcon(
notification.type
);

const content =
document.createElement(
"div"
);

content.className =
"notification-content";

const titleRow =
document.createElement(
"div"
);

titleRow.className =
"notification-title-row";

const title =
document.createElement(
"strong"
);

title.className =
"notification-title";

title.textContent =
notification.title ||
"MarketHub Notification";

titleRow.appendChild(
title
);

if (!notification.is_read) {

const dot =
  document.createElement(
    "span"
  );

dot.className =
  "unread-dot";

dot.setAttribute(
  "aria-label",
  "Unread"
);

titleRow.appendChild(
  dot
);

}

const message =
document.createElement(
"p"
);

message.className =
"notification-message";

message.textContent =
notification.message ||
"";

const time =
document.createElement(
"time"
);

time.className =
"notification-time";

time.textContent =
formatNotificationDate(
notification.created_at
);

content.appendChild(
titleRow
);

content.appendChild(
message
);

content.appendChild(
time
);

card.appendChild(
icon
);

card.appendChild(
content
);

card.addEventListener(
"click",
() => {

  handleNotificationClick(
    notification
  );

}

);

return card;

}

/* =========================================================
NOTIFICATION TYPE
========================================================= */

function getNotificationClass(
type
) {

const value =
String(type || "")
.toLowerCase();

if (
value === "payment" ||
value === "payment_approved"
) {

return "payment";

}

if (
value === "cancelled" ||
value === "cancellation"
) {

return "cancelled";

}

if (
value === "admin" ||
value === "message"
) {

return "admin";

}

if (
value === "order" ||
value === "order_status"
) {

return "order";

}

return "system";

}

function getNotificationIcon(
type
) {

const value =
String(type || "")
.toLowerCase();

if (
value === "payment" ||
value === "payment_approved"
) {

return "✓";

}

if (
value === "cancelled" ||
value === "cancellation"
) {

return "×";

}

if (
value === "admin" ||
value === "message"
) {

return "✉";

}

if (
value === "order" ||
value === "order_status"
) {

return "📦";

}

return "🔔";

}

/* =========================================================
CLICK NOTIFICATION
========================================================= */

async function handleNotificationClick(
notification
) {

if (!notification.is_read) {

const {
  error
} =
  await marketHubCustomer
    .from(
      "customer_notifications"
    )
    .update({
      is_read: true
    })
    .eq(
      "id",
      notification.id
    )
    .eq(
      "customer_id",
      currentUser.id
    );


if (!error) {

  notification.is_read =
    true;

  renderNotifications();

}

}

/*
If this notification belongs
to an order, we can later use
related_order_id to open the
specific order.
*/

}

/* =========================================================
MARK ALL READ
========================================================= */

async function markAllAsRead() {

if (!currentUser) {
return;
}

const unread =
allNotifications.filter(
notification =>
!notification.is_read
);

if (unread.length === 0) {

showToast(
  "All notifications are already read."
);

return;

}

markAllButton.disabled =
true;

const {
error
} =
await marketHubCustomer
.from(
"customer_notifications"
)
.update({
is_read: true
})
.eq(
"customer_id",
currentUser.id
)
.eq(
"is_read",
false
);

markAllButton.disabled =
false;

if (error) {

showToast(
  error.message ||
  "Unable to mark notifications as read."
);

return;

}

allNotifications.forEach(
notification => {

  notification.is_read =
    true;

}

);

renderNotifications();

showToast(
"All notifications marked as read."
);

}

/* =========================================================
MARK ALL BUTTON
========================================================= */

function updateMarkAllButton() {

if (!markAllButton) {
return;
}

const unreadCount =
allNotifications.filter(
notification =>
!notification.is_read
).length;

markAllButton.disabled =
unreadCount === 0;

}

/* =========================================================
DATE FORMAT
========================================================= */

function formatNotificationDate(
value
) {

if (!value) {
return "";
}

const date =
new Date(value);

if (
Number.isNaN(
date.getTime()
)
) {

return "";

}

const now =
new Date();

const difference =
now.getTime() -
date.getTime();

const minute =
60 * 1000;

const hour =
60 * minute;

const day =
24 * hour;

if (difference < minute) {

return "Just now";

}

if (difference < hour) {

const minutes =
  Math.floor(
    difference / minute
  );

return `${minutes} minute${
  minutes === 1
    ? ""
    : "s"
} ago`;

}

if (difference < day) {

const hours =
  Math.floor(
    difference / hour
  );

return `${hours} hour${
  hours === 1
    ? ""
    : "s"
} ago`;

}

if (difference < 7 * day) {

const days =
  Math.floor(
    difference / day
  );

return `${days} day${
  days === 1
    ? ""
    : "s"
} ago`;

}

return date.toLocaleDateString(
undefined,
{
day: "numeric",
month: "short",
year: "numeric"
}
);

}

/* =========================================================
LOADING / ERROR
========================================================= */

function showLoading() {

if (notificationsLoading) {

notificationsLoading.style.display =
  "flex";

}

if (notificationsEmpty) {

notificationsEmpty.classList.remove(
  "show"
);

}

if (notificationList) {

notificationList.style.display =
  "none";

}

}

function hideLoading() {

if (notificationsLoading) {

notificationsLoading.style.display =
  "none";

}

}

function showError(
message
) {

hideLoading();

if (notificationsError) {

notificationsError.classList.add(
  "show"
);

}

if (notificationsErrorText) {

notificationsErrorText.textContent =
  message ||
  "Something went wrong.";

}

if (notificationList) {

notificationList.style.display =
  "none";

}

if (notificationsEmpty) {

notificationsEmpty.classList.remove(
  "show"
);

}

}

function hideError() {

if (notificationsError) {

notificationsError.classList.remove(
  "show"
);

}

}

/* =========================================================
TOAST
========================================================= */

let toastTimer = null;

function showToast(
message
) {

if (!toast) {
return;
}

toast.textContent =
message;

toast.classList.add(
"show"
);

clearTimeout(
toastTimer
);

toastTimer =
setTimeout(
() => {

    toast.classList.remove(
      "show"
    );

  },
  2500
);

}

/* =========================================================
AUTH STATE
========================================================= */

marketHubCustomer
.auth
.onAuthStateChange(
(
event,
session
) => {

  if (
    event ===
    "SIGNED_OUT"
  ) {

    window.location.href =
      "login.html";

    return;

  }


  if (
    event ===
    "SIGNED_IN" &&
    session?.user
  ) {

    currentUser =
      session.user;

    loadNotifications();

  }

}

);