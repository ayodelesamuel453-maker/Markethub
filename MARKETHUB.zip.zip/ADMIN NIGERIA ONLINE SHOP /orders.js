const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";


const supabaseClient =
  window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await supabaseClient.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


// ==============================
// STATE
// ==============================

let currentUser = null;

let orders = [];

let selectMode = false;

let selectedOrderIds = new Set();


// ==============================
// START
// ==============================

document.addEventListener(
  "DOMContentLoaded",
  async () => {

    setupButtons();

    await initializeOrders();

  }
);


// ==============================
// INITIALIZE
// ==============================

async function initializeOrders() {

  showLoading();


  /*
    Check authentication before
    allowing access to the orders page.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {

    return;

  }


  try {

    /*
      Load the currently authenticated
      customer.
    */

    const {
      data,
      error
    } =
      await supabaseClient.auth.getUser();


    if (error) {

      throw error;

    }


    currentUser =
      data?.user || null;


    if (!currentUser) {

      window.location.replace(
        "login.html"
      );

      return;

    }


    await loadOrders();


  } catch (error) {

    console.error(
      "ORDERS INITIALIZATION ERROR:",
      error
    );


    showError(
      error.message ||
      "Unable to load your orders."
    );

  }

}

// ==============================
// BUTTONS
// ==============================

function setupButtons() {

  document
    .getElementById("backButton")
    ?.addEventListener(
      "click",
      () => {

        window.location.href =
          "index.html";

      }
    );


  document
    .getElementById("shopNowButton")
    ?.addEventListener(
      "click",
      () => {

        window.location.href =
          "index.html";

      }
    );


  document
    .getElementById("retryButton")
    ?.addEventListener(
      "click",
      async () => {

        await initializeOrders();

      }
    );


  document
    .getElementById("deleteModeButton")
    ?.addEventListener(
      "click",
      enterSelectMode
    );


  document
    .getElementById("cancelSelectButton")
    ?.addEventListener(
      "click",
      exitSelectMode
    );


  document
    .getElementById("deleteSelectedButton")
    ?.addEventListener(
      "click",
      openDeleteConfirmation
    );


  document
    .getElementById("confirmCancel")
    ?.addEventListener(
      "click",
      closeDeleteConfirmation
    );


  document
    .getElementById("confirmDelete")
    ?.addEventListener(
      "click",
      deleteSelectedOrders
    );


  /*
    Close confirmation when clicking
    outside the confirmation card.
  */

  document
    .getElementById("confirmOverlay")
    ?.addEventListener(
      "click",
      event => {

        if (
          event.target.id ===
          "confirmOverlay"
        ) {

          closeDeleteConfirmation();

        }

      }
    );

}


// ==============================
// LOAD ORDERS
// ==============================

async function loadOrders() {

  showLoading();


  if (!currentUser) {

    showError(
      "Please sign in to view your orders."
    );

    return;

  }


  try {

    /*
      The customer's orders are now
      loaded directly using the current
      orders.customer_id column.

      RLS also protects this query,
      but keeping the customer filter
      here makes the request explicit.
    */

    const ordersResult =
      await supabaseClient
        .from("orders")
        .select(`
          id,
          customer_id,
          customer_name,
          customer_phone,
          customer_email,
          delivery_address,
          delivery_city,
          delivery_state,
          payment_method,
          payment_status,
          order_status,
          subtotal,
          delivery_fee,
          total,
          transfer_screenshot,
          admin_note,
          created_at,
          updated_at,
          customer_deleted
        `)
        .eq(
          "customer_id",
          currentUser.id
        )
        .or(
          "customer_deleted.eq.false,customer_deleted.is.null"
        )
        .order(
          "created_at",
          {
            ascending: false
          }
        );


    if (ordersResult.error) {

      throw ordersResult.error;

    }


    const loadedOrders =
      ordersResult.data || [];


    /*
      Load order items for every order.
    */

    for (
      const order of loadedOrders
    ) {

      const itemsResult =
        await supabaseClient
          .from("order_items")
          .select(`
            id,
            order_id,
            product_id,
            product_name,
            product_image,
            quantity,
            unit_price,
            subtotal,
            variant,
            created_at
          `)
          .eq(
            "order_id",
            order.id
          )
          .order(
            "created_at",
            {
              ascending: true
            }
          );


      if (itemsResult.error) {

        throw itemsResult.error;

      }


      order.order_items =
        itemsResult.data || [];

    }


    orders =
      loadedOrders;


    hideLoading();


    if (!orders.length) {

      showEmpty();

      return;

    }


    renderOrders();


  } catch (error) {

    console.error(
      "MARKETHUB ORDERS ERROR:",
      error
    );


    hideLoading();


    showError(
      error.message ||
      "Unable to load your orders."
    );

  }

}


// ==============================
// RENDER ORDERS
// ==============================

function renderOrders() {

  const list =
    document.getElementById(
      "ordersList"
    );


  if (!list) return;


  list.innerHTML = "";


  list.style.display =
    "block";


  orders.forEach(
    order => {

      const card =
        createOrderCard(
          order
        );


      list.appendChild(
        card
      );

    }
  );


  updateSelectionUI();

}


// ==============================
// ORDER CARD
// ==============================

function createOrderCard(order) {

  const card =
    document.createElement("article");


  card.className =
    "order-card";


  if (selectMode) {

    card.classList.add(
      "selectable"
    );

  }


  if (
    selectedOrderIds.has(order.id)
  ) {

    card.classList.add(
      "selected"
    );

  }


  card.addEventListener(
    "click",
    () => {

      if (!selectMode) {
        return;
      }

      toggleOrderSelection(
        order.id
      );

    }
  );


  const items =
    Array.isArray(order.order_items)
      ? order.order_items
      : [];


  const payment =
    getPaymentStatus(
      order.payment_status
    );


  const orderStatus =
    getOrderStatus(
      order.order_status
    );


  const paymentMethod =
    getPaymentMethod(
      order.payment_method
    );


  const rawStatus =
    String(
      order.order_status ||
      "pending"
    )
      .toLowerCase()
      .trim()
      .replace(
        /[^a-z0-9]+/g,
        "-"
      );


  const productHtml =
    items.length
      ? items
          .map(
            item =>
              createProductHtml(item)
          )
          .join("")
      : `
          <div class="order-product">

            <div class="product-info">

              <div class="product-name">
                No products found
              </div>

            </div>

          </div>
        `;


  const deliveryLocation =
    [
      order.delivery_city,
      order.delivery_state
    ]
      .filter(Boolean)
      .join(", ");


  card.innerHTML = `

    ${
      selectMode
        ? `
          <div class="order-select-check">
            ${
              selectedOrderIds.has(order.id)
                ? "✓"
                : ""
            }
          </div>
        `
        : ""
    }


    <div class="order-top">

      <div class="order-number">

        <span>
          Order ID
        </span>

        <strong>
          ${escapeHtml(
            order.id || "—"
          )}
        </strong>

      </div>


      <div class="order-date">

        ${formatDate(
          order.created_at
        )}

      </div>

    </div>


    ${productHtml}


    <div class="payment-row">

      <span class="payment-label">
        Payment
      </span>


      <span class="payment-badge ${payment.className}">
        ${payment.label}
      </span>

    </div>


    <div class="order-status-row">

      <span class="order-status-label">
        Payment Method
      </span>


      <span class="order-status-value">
        ${escapeHtml(
          paymentMethod
        )}
      </span>

    </div>


    <div class="order-status-row">

      <span class="order-status-label">
        Order Status
      </span>


      <span class="order-status-value order-status-${rawStatus}">
        ${escapeHtml(
          orderStatus
        )}
      </span>

    </div>


    ${
      deliveryLocation
        ? `
          <div class="order-status-row">

            <span class="order-status-label">
              Delivery
            </span>

            <span class="order-status-value">
              ${escapeHtml(
                deliveryLocation
              )}
            </span>

          </div>
        `
        : ""
    }


    <div class="order-bottom">

      <span>
        Order Total
      </span>


      <strong>
        ${formatNaira(
          order.total
        )}
      </strong>

    </div>

  `;


  return card;

}

// ==============================
// PRODUCT HTML
// ==============================

function createProductHtml(
  item
) {

  const productName =
    item.product_name ||
    "Product";


  const productId =
    item.product_id ||
    "—";


  const quantity =
    Number(
      item.quantity || 1
    );


  const unitPrice =
    Number(
      item.unit_price || 0
    );


  const subtotal =
    Number(
      item.subtotal ??
      unitPrice * quantity
    );


  const image =
    item.product_image ||
    "";


  const variant =
    item.variant ||
    "";


  return `

    <div class="order-product">

      ${
        image
          ? `
            <img
              class="product-image"
              src="${escapeAttribute(
                image
              )}"
              alt="${escapeAttribute(
                productName
              )}"
              onerror="
                this.style.display='none'
              "
            >
          `
          : `
            <div
              class="product-image"
              style="
                display:flex;
                align-items:center;
                justify-content:center;
                font-size:24px;
              "
            >
              🛍️
            </div>
          `
      }


      <div class="product-info">

        <div class="product-name">

          ${escapeHtml(
            productName
          )}

        </div>


        <div class="product-id">

          Product ID:

          <strong>
            ${escapeHtml(
              productId
            )}
          </strong>

        </div>


        ${
          variant
            ? `
              <div class="product-quantity">

                Variant:

                <strong>
                  ${escapeHtml(
                    variant
                  )}
                </strong>

              </div>
            `
            : ""
        }


        <div class="product-quantity">

          Quantity:

          <strong>
            ${quantity}
          </strong>

        </div>


        <div class="product-quantity">

          ${formatNaira(
            unitPrice
          )}
          each

        </div>

      </div>


      <div class="product-price">

        <span>
          Amount
        </span>


        <strong>
          ${formatNaira(
            subtotal
          )}
        </strong>

      </div>

    </div>

  `;

}


// ==============================
// PAYMENT STATUS
// ==============================

function getPaymentStatus(
  status
) {

  const value =
    String(
      status || ""
    )
      .toLowerCase()
      .trim();


  if (

    value === "approved" ||
    value === "paid" ||
    value === "payment approved" ||
    value === "received" ||
    value === "payment received" ||
    value === "confirmed"

  ) {

    return {

      label:
        "Payment Approved",

      className:
        "approved"

    };

  }


  if (

    value === "failed" ||
    value === "cancelled" ||
    value === "canceled"

  ) {

    return {

      label:
        "Payment Failed",

      className:
        "failed"

    };

  }


  return {

    label:
      "Payment Pending",

    className:
      "pending"

  };

}


// ==============================
// ORDER STATUS
// ==============================

function getOrderStatus(
  status
) {

  const value =
    String(
      status || "pending"
    )
      .trim();


  if (!value) {

    return "Pending";

  }


  return value
    .replace(
      /[_-]+/g,
      " "
    )
    .replace(
      /\s+/g,
      " "
    )
    .replace(
      /\b\w/g,
      character =>
        character.toUpperCase()
    );

}


// ==============================
// PAYMENT METHOD
// ==============================

function getPaymentMethod(
  method
) {

  const value =
    String(
      method || ""
    )
      .toLowerCase()
      .trim();


  if (
    value === "bank_transfer" ||
    value === "bank transfer" ||
    value === "transfer"
  ) {

    return "Bank Transfer";

  }


  if (
    value === "cash_on_delivery" ||
    value === "cash on delivery" ||
    value === "cod"
  ) {

    return "Cash on Delivery";

  }


  if (!value) {

    return "Not specified";

  }


  return value
    .replace(
      /[_-]+/g,
      " "
    )
    .replace(
      /\s+/g,
      " "
    )
    .replace(
      /\b\w/g,
      character =>
        character.toUpperCase()
    );

}


// ==============================
// ENTER SELECT MODE
// ==============================

function enterSelectMode() {

  if (!orders.length) {

    return;

  }


  selectMode =
    true;


  selectedOrderIds.clear();


  const deleteButton =
    document.getElementById(
      "deleteModeButton"
    );


  const cancelButton =
    document.getElementById(
      "cancelSelectButton"
    );


  const selectInfo =
    document.getElementById(
      "selectInfo"
    );


  const deleteBar =
    document.getElementById(
      "deleteBar"
    );


  if (deleteButton) {

    deleteButton.style.display =
      "none";

  }


  if (cancelButton) {

    cancelButton.style.display =
      "block";

  }


  if (selectInfo) {

    selectInfo.style.display =
      "flex";

  }


  if (deleteBar) {

    deleteBar.style.display =
      "flex";

  }


  renderOrders();

  updateSelectionUI();

}


// ==============================
// EXIT SELECT MODE
// ==============================

function exitSelectMode() {

  selectMode =
    false;


  selectedOrderIds.clear();


  resetSelectUI();

  renderOrders();

}


// ==============================
// TOGGLE ORDER SELECTION
// ==============================

function toggleOrderSelection(
  orderId
) {

  if (
    selectedOrderIds.has(
      orderId
    )
  ) {

    selectedOrderIds.delete(
      orderId
    );

  } else {

    selectedOrderIds.add(
      orderId
    );

  }


  renderOrders();

  updateSelectionUI();

}


// ==============================
// SELECTION UI
// ==============================

function updateSelectionUI() {

  const count =
    selectedOrderIds.size;


  const selectedCount =
    document.getElementById(
      "selectedCount"
    );


  const deleteCount =
    document.getElementById(
      "deleteCount"
    );


  const deleteButton =
    document.getElementById(
      "deleteSelectedButton"
    );


  if (selectedCount) {

    selectedCount.textContent =
      `${count} selected`;

  }


  if (deleteCount) {

    deleteCount.textContent =
      count;

  }


  if (deleteButton) {

    deleteButton.disabled =
      count === 0;


    deleteButton.textContent =
      count
        ? `Delete ${count} Order${count === 1 ? "" : "s"}`
        : "Delete Selected";

  }

}


// ==============================
// DELETE CONFIRMATION
// ==============================

function openDeleteConfirmation() {

  if (
    selectedOrderIds.size === 0
  ) {

    return;

  }


  const overlay =
    document.getElementById(
      "confirmOverlay"
    );


  const confirmText =
    document.getElementById(
      "confirmText"
    );


  const count =
    selectedOrderIds.size;


  if (confirmText) {

    confirmText.textContent =
      `${count} selected order${count === 1 ? "" : "s"} will be removed from your order history.`;

  }


  if (overlay) {

    overlay.classList.add(
      "show"
    );

  }

}


// ==============================
// CLOSE CONFIRMATION
// ==============================

function closeDeleteConfirmation() {

  const overlay =
    document.getElementById(
      "confirmOverlay"
    );


  if (overlay) {

    overlay.classList.remove(
      "show"
    );

  }

}


// ==============================
// DELETE SELECTED ORDERS
// ==============================

async function deleteSelectedOrders() {

  if (
    selectedOrderIds.size === 0
  ) {

    return;

  }


  if (!currentUser) {

    showToast(
      "Please sign in again."
    );

    return;

  }


  const ids =
    Array.from(
      selectedOrderIds
    );


  const confirmButton =
    document.getElementById(
      "confirmDelete"
    );


  if (confirmButton) {

    confirmButton.disabled =
      true;

    confirmButton.textContent =
      "Deleting...";

  }


  try {

    /*
      We do NOT physically delete
      the order.

      We only mark it as hidden for
      this customer using the current
      customer_deleted column.
    */

    const result =
      await supabaseClient
        .from("orders")
        .update({
          customer_deleted: true
        })
        .eq(
          "customer_id",
          currentUser.id
        )
        .in(
          "id",
          ids
        );


    if (result.error) {

      throw result.error;

    }


    /*
      Remove the last-order reference
      if necessary.
    */

    const lastOrderKeys = [

      "marketHubLastOrderId",

      currentUser
        ? `marketHubLastOrderId_${currentUser.id}`
        : null

    ]
      .filter(Boolean);


    lastOrderKeys.forEach(
      key => {

        const lastOrderId =
          localStorage.getItem(
            key
          );


        if (
          lastOrderId &&
          ids.includes(
            lastOrderId
          )
        ) {

          localStorage.removeItem(
            key
          );

        }

      }
    );


    closeDeleteConfirmation();


    selectedOrderIds.clear();

    selectMode =
      false;


    showToast(
      `${ids.length} order${ids.length === 1 ? "" : "s"} removed`
    );


    await loadOrders();


    resetSelectUI();


  } catch (error) {

    console.error(
      "DELETE ORDERS ERROR:",
      error
    );


    closeDeleteConfirmation();


    showError(
      error.message ||
      "Unable to delete selected orders."
    );


  } finally {

    if (confirmButton) {

      confirmButton.disabled =
        false;

      confirmButton.textContent =
        "Delete";

    }

  }

}


// ==============================
// RESET SELECT UI
// ==============================

function resetSelectUI() {

  const deleteButton =
    document.getElementById(
      "deleteModeButton"
    );


  const cancelButton =
    document.getElementById(
      "cancelSelectButton"
    );


  const selectInfo =
    document.getElementById(
      "selectInfo"
    );


  const deleteBar =
    document.getElementById(
      "deleteBar"
    );


  if (deleteButton) {

    deleteButton.style.display =
      "flex";

  }


  if (cancelButton) {

    cancelButton.style.display =
      "none";

  }


  if (selectInfo) {

    selectInfo.style.display =
      "none";

  }


  if (deleteBar) {

    deleteBar.style.display =
      "none";

  }

}


// ==============================
// DATE
// ==============================

function formatDate(
  value
) {

  if (!value) {

    return "—";

  }


  const date =
    new Date(value);


  if (
    Number.isNaN(
      date.getTime()
    )
  ) {

    return "—";

  }


  return date.toLocaleDateString(
    "en-NG",
    {
      day: "numeric",
      month: "short",
      year: "numeric"
    }
  );

}


// ==============================
// NAIRA
// ==============================

function formatNaira(
  amount
) {

  return new Intl.NumberFormat(
    "en-NG",
    {
      style: "currency",
      currency: "NGN",
      maximumFractionDigits: 0
    }
  ).format(
    Number(
      amount || 0
    )
  );

}


// ==============================
// LOADING
// ==============================

function showLoading() {

  const loading =
    document.getElementById(
      "ordersLoading"
    );


  const empty =
    document.getElementById(
      "emptyOrders"
    );


  const error =
    document.getElementById(
      "ordersError"
    );


  const list =
    document.getElementById(
      "ordersList"
    );


  if (loading) {

    loading.style.display =
      "block";

  }


  if (empty) {

    empty.style.display =
      "none";

  }


  if (error) {

    error.style.display =
      "none";

  }


  if (list) {

    list.style.display =
      "none";

  }

}


// ==============================
// HIDE LOADING
// ==============================

function hideLoading() {

  const loading =
    document.getElementById(
      "ordersLoading"
    );


  if (loading) {

    loading.style.display =
      "none";

  }

}


// ==============================
// EMPTY
// ==============================

function showEmpty() {

  const empty =
    document.getElementById(
      "emptyOrders"
    );


  const list =
    document.getElementById(
      "ordersList"
    );


  const error =
    document.getElementById(
      "ordersError"
    );


  if (empty) {

    empty.style.display =
      "block";

  }


  if (list) {

    list.style.display =
      "none";

  }


  if (error) {

    error.style.display =
      "none";

  }


  resetSelectUI();

}


// ==============================
// ERROR
// ==============================

function showError(
  message
) {

  const error =
    document.getElementById(
      "ordersError"
    );


  const errorText =
    document.getElementById(
      "ordersErrorText"
    );


  if (errorText) {

    errorText.textContent =
      message;

  }


  if (error) {

    error.style.display =
      "block";

  }

}


// ==============================
// TOAST
// ==============================

function showToast(
  message
) {

  const toast =
    document.getElementById(
      "toast"
    );


  if (!toast) return;


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  setTimeout(
    () => {

      toast.classList.remove(
        "show"
      );

    },
    2500
  );

}


// ==============================
// SECURITY
// ==============================

function escapeHtml(
  value
) {

  return String(
    value ?? ""
  )

    .replace(
      /&/g,
      "&amp;"
    )

    .replace(
      /</g,
      "&lt;"
    )

    .replace(
      />/g,
      "&gt;"
    )

    .replace(
      /"/g,
      "&quot;"
    )

    .replace(
      /'/g,
      "&#039;"
    );

}


function escapeAttribute(
  value
) {

  return escapeHtml(
    value
  );

}