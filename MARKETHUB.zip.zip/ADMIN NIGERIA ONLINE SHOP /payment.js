/* =========================================================
   MARKET HUB � PAYMENT
   Current Cart + Checkout  Order
========================================================= */


/* =========================================================
   SUPABASE
========================================================= */

const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const supabaseClient =
  window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await supabaseClient.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


/* =========================================================
   SETTINGS
========================================================= */

const CART_KEY =
  "marketHubCart";

const CHECKOUT_KEY_PREFIX =
  "marketHubCheckout_";

const TRANSFER_BUCKET =
  "order-transfer-screenshots";

const LAST_ORDER_KEY_PREFIX =
  "marketHubLastOrderId_";


/* =========================================================
   DEFAULT PAYMENT SETTINGS
========================================================= */

const DEFAULT_PAYMENT_SETTINGS = {

  bankTransferEnabled:
    true,

  cashOnDeliveryEnabled:
    true,

  bankName:
    "",

  accountName:
    "",

  accountNumber:
    "",

  paymentInstructions:
    "",

  orderConfirmationMessage:
    ""

};


/* =========================================================
   STATE
========================================================= */

let currentUser =
  null;

let cart =
  [];

let checkoutData =
  {};

let selectedPayment =
  "";

let screenshotFile =
  null;

let isProcessing =
  false;

let paymentSettings =
  {
    ...DEFAULT_PAYMENT_SETTINGS
  };

let paymentSettingsLoaded =
  false;


/* =========================================================
   STORAGE KEYS
========================================================= */

function getCheckoutKey() {

  if (!currentUser) {
    return null;
  }

  return (
    CHECKOUT_KEY_PREFIX +
    currentUser.id
  );
}


function getLastOrderKey() {

  if (!currentUser) {
    return null;
  }

  return (
    LAST_ORDER_KEY_PREFIX +
    currentUser.id
  );
}


/* =========================================================
   FORMAT NAIRA
========================================================= */

function formatNaira(
  amount
) {

  return new Intl.NumberFormat(
    "en-NG",
    {
      style:
        "currency",

      currency:
        "NGN",

      maximumFractionDigits:
        0
    }
  ).format(
    Number(amount) || 0
  );
}


/* =========================================================
   TOAST
========================================================= */

function showToast(
  message
) {

  const toast =
    document.getElementById(
      "toast"
    );


  if (!toast) {
    return;
  }


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  clearTimeout(
    window.marketHubToastTimer
  );


  window.marketHubToastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2800
    );
}


/* =========================================================
   FILE SIZE
========================================================= */

function formatFileSize(
  bytes
) {

  if (
    bytes < 1024
  ) {

    return (
      bytes +
      " B"
    );
  }


  if (
    bytes <
    1024 * 1024
  ) {

    return (
      bytes / 1024
    ).toFixed(1) +
    " KB";
  }


  return (
    bytes /
    (1024 * 1024)
  ).toFixed(1) +
  " MB";
}


/* =========================================================
   FILE EXTENSION
========================================================= */

function getFileExtension(
  filename
) {

  const parts =
    String(
      filename || ""
    ).split(
      "."
    );


  if (
    parts.length < 2
  ) {

    return "jpg";
  }


  return parts
    .pop()
    .toLowerCase();
}


/* =========================================================
   LOAD CURRENT USER
========================================================= */

async function loadCurrentUser() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient
        .auth
        .getSession();


    if (error) {
      throw error;
    }


    const session =
      data?.session ||
      null;


    if (!session?.user) {

      currentUser =
        null;


      showLoginRequired();


      return false;
    }


    currentUser =
      session.user;


    return true;

  } catch (error) {

    console.error(
      "PAYMENT AUTH ERROR:",
      error
    );


    currentUser =
      null;


    showLoginRequired();


    return false;
  }
}


/* =========================================================
   LOGIN REQUIRED
========================================================= */

function showLoginRequired() {

  const existing =
    document.getElementById(
      "paymentLoginRequired"
    );


  if (existing) {
    return;
  }


  const main =
    document.querySelector(
      "main"
    ) ||
    document.body;


  main.innerHTML = `

    <section
      id="paymentLoginRequired"
      style="
        min-height:60vh;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:24px 16px;
        box-sizing:border-box;
      "
    >

      <div
        style="
          width:min(100%,420px);
          background:#ffffff;
          border:1px solid #e8e8e8;
          border-radius:18px;
          padding:24px 20px;
          text-align:center;
          box-shadow:0 8px 30px rgba(0,0,0,.06);
          box-sizing:border-box;
        "
      >

        <div
          style="
            width:48px;
            height:48px;
            margin:0 auto 14px;
            border-radius:50%;
            background:#fff4e8;
            color:#ff7900;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:22px;
          "
        >
          
        </div>


        <h2
          style="
            margin:0 0 7px;
            font-size:20px;
            color:#171717;
          "
        >
          Login required
        </h2>


        <p
          style="
            margin:0 0 20px;
            color:#707070;
            font-size:14px;
            line-height:1.5;
          "
        >
          Please log in to continue with your payment.
        </p>


        <div
          style="
            display:flex;
            gap:10px;
            justify-content:center;
            flex-wrap:wrap;
          "
        >

          <button
            type="button"
            id="paymentLoginButton"
            style="
              border:0;
              background:#ff7900;
              color:#fff;
              border-radius:11px;
              padding:12px 18px;
              font-weight:700;
              cursor:pointer;
            "
          >
            Go to Login
          </button>


          <button
            type="button"
            id="paymentShopButton"
            style="
              border:1px solid #dedede;
              background:#fff;
              color:#333;
              border-radius:11px;
              padding:12px 18px;
              font-weight:700;
              cursor:pointer;
            "
          >
            Back to Shop
          </button>

        </div>

      </div>

    </section>

  `;


  const loginButton =
    document.getElementById(
      "paymentLoginButton"
    );


  const shopButton =
    document.getElementById(
      "paymentShopButton"
    );


  if (loginButton) {

    loginButton.onclick =
      () => {

        window.location.href =
          "login.html";
      };
  }


  if (shopButton) {

    shopButton.onclick =
      () => {

        window.location.href =
          "index.html";
      };
  }
}


/* =========================================================
   READ SHARED CART
========================================================= */

function getCart() {

  try {

    const saved =
      localStorage.getItem(
        CART_KEY
      );


    if (!saved) {
      return [];
    }


    const parsed =
      JSON.parse(
        saved
      );


    if (!Array.isArray(parsed)) {
      return [];
    }


    return parsed.filter(
      item =>
        item &&
        item.product_id
    );

  } catch (error) {

    console.error(
      "PAYMENT CART ERROR:",
      error
    );


    return [];
  }
}


/* =========================================================
   READ CHECKOUT DATA
========================================================= */

function getCheckoutData() {

  const key =
    getCheckoutKey();


  if (!key) {
    return {};
  }


  try {

    const saved =
      localStorage.getItem(
        key
      );


    if (!saved) {
      return {};
    }


    const parsed =
      JSON.parse(
        saved
      );


    if (
      !parsed ||
      typeof parsed !== "object"
    ) {

      return {};
    }


    return parsed;

  } catch (error) {

    console.error(
      "CHECKOUT DATA ERROR:",
      error
    );


    return {};
  }
}


/* =========================================================
   SUBTOTAL
========================================================= */

function getSubtotal() {

  return cart.reduce(
    (
      total,
      item
    ) => {

      const price =
        Number(
          item.unit_price
        ) || 0;


      const quantity =
        Math.max(
          1,
          Number(
            item.quantity
          ) || 1
        );


      return (
        total +
        (
          price *
          quantity
        )
      );

    },
    0
  );
}


/* =========================================================
   ITEM COUNT
========================================================= */

function getItemCount() {

  return cart.reduce(
    (
      total,
      item
    ) => {

      return (
        total +
        Math.max(
          1,
          Number(
            item.quantity
          ) || 1
        )
      );

    },
    0
  );
}


/* =========================================================
   LOAD PUBLIC PAYMENT SETTINGS
========================================================= */

async function loadPaymentSettings() {

  try {

    /*
      IMPORTANT:
      These bank details now come directly from
      market_hub_public_settings.

      The public view must contain:

      bank_name
      bank_account_name
      bank_account_number
    */

    const {
      data,
      error
    } =
      await supabaseClient
        .from(
          "market_hub_public_settings"
        )
        .select(`
          bank_transfer_enabled,
          cash_on_delivery_enabled,
          bank_name,
          bank_account_name,
          bank_account_number,
          payment_instructions,
          order_confirmation_message
        `)
        .eq(
          "id",
          1
        )
        .maybeSingle();


    if (error) {

      console.error(
        "PUBLIC PAYMENT SETTINGS ERROR:",
        error
      );


      paymentSettings =
        {
          ...DEFAULT_PAYMENT_SETTINGS
        };


      paymentSettingsLoaded =
        false;


      return false;
    }


    paymentSettings = {

      bankTransferEnabled:
        data?.bank_transfer_enabled !== false,

      cashOnDeliveryEnabled:
        data?.cash_on_delivery_enabled !== false,

      bankName:
        String(
          data?.bank_name ||
          ""
        ).trim(),

      accountName:
        String(
          data?.bank_account_name ||
          ""
        ).trim(),

      accountNumber:
        String(
          data?.bank_account_number ||
          ""
        ).trim(),

      paymentInstructions:
        String(
          data?.payment_instructions ||
          ""
        ).trim(),

      orderConfirmationMessage:
        String(
          data?.order_confirmation_message ||
          ""
        ).trim()

    };


    paymentSettingsLoaded =
      true;


    console.log(
      "MARKET HUB PAYMENT SETTINGS:",
      {
        bankTransferEnabled:
          paymentSettings.bankTransferEnabled,

        cashOnDeliveryEnabled:
          paymentSettings.cashOnDeliveryEnabled,

        bankName:
          paymentSettings.bankName,

        accountName:
          paymentSettings.accountName,

        accountNumber:
          paymentSettings.accountNumber
      }
    );


    return true;

  } catch (error) {

    console.error(
      "PAYMENT SETTINGS ERROR:",
      error
    );


    paymentSettings =
      {
        ...DEFAULT_PAYMENT_SETTINGS
      };


    paymentSettingsLoaded =
      false;


    return false;
  }
}


/* =========================================================
   INITIALIZE
========================================================= */

document.addEventListener(
  "DOMContentLoaded",
  initializePayment
);


async function initializePayment() {

  /*
    Check authentication before
    allowing access to payment.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {
    return;
  }


  /*
    Load the authenticated user.
  */

  const userLoaded =
    await loadCurrentUser();


  if (!userLoaded) {
    return;
  }


  /*
    Always use the shared cart.
    Never clear it simply because
    payment.html was opened.
  */

  cart =
    getCart();


  checkoutData =
    getCheckoutData();


  if (!cart.length) {

    showEmptyPayment();

    return;
  }


  await loadPaymentSettings();


  setupPage();
}

/* =========================================================
   EMPTY PAYMENT
========================================================= */

function showEmptyPayment() {

  const main =
    document.querySelector(
      "main"
    );


  if (!main) {
    return;
  }


  main.innerHTML = `

    <section
      style="
        min-height:55vh;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:24px 16px;
        box-sizing:border-box;
      "
    >

      <div
        style="
          width:min(100%,420px);
          text-align:center;
          background:#fff;
          border:1px solid #e8e8e8;
          border-radius:18px;
          padding:24px 20px;
          box-shadow:0 8px 30px rgba(0,0,0,.05);
        "
      >

        <div
          style="
            font-size:34px;
            margin-bottom:10px;
          "
        >
          
        </div>


        <h2
          style="
            margin:0 0 7px;
            font-size:20px;
          "
        >
          No order to pay for
        </h2>


        <p
          style="
            margin:0 0 18px;
            color:#777;
            font-size:14px;
          "
        >
          Your cart is empty.
        </p>


        <button
          type="button"
          onclick="window.location.href='index.html'"
          style="
            border:0;
            background:#ff7900;
            color:#fff;
            border-radius:11px;
            padding:12px 20px;
            font-weight:700;
            cursor:pointer;
          "
        >
          Continue Shopping
        </button>

      </div>

    </section>

  `;
}


/* =========================================================
   SETUP PAGE
========================================================= */

function setupPage() {

  renderOrder();

  renderPaymentInstructions();

  renderBankDetails();

  renderCustomerDetails();

  setupPaymentMethods();

  setupScreenshotUpload();

  setupCopyButton();

  setupNavigation();

  setupConfirmButton();

  updatePaymentMethodVisibility();

  updateConfirmButton();
}


/* =========================================================
   RENDER ORDER SUMMARY
========================================================= */

function renderOrder() {

  const subtotal =
    getSubtotal();


  const deliveryFee =
    Number(
      checkoutData.deliveryFee
    ) || 0;


  const total =
    subtotal +
    deliveryFee;


  const itemCount =
    getItemCount();


  const orderTotal =
    document.getElementById(
      "orderTotal"
    );


  const itemCountElement =
    document.getElementById(
      "itemCount"
    );


  const summarySubtotal =
    document.getElementById(
      "summarySubtotal"
    );


  const deliveryFeeElement =
    document.getElementById(
      "deliveryFee"
    );


  const summaryTotal =
    document.getElementById(
      "summaryTotal"
    );


  const confirmAmount =
    document.getElementById(
      "confirmAmount"
    );


  if (orderTotal) {

    orderTotal.textContent =
      formatNaira(
        total
      );
  }


  if (itemCountElement) {

    itemCountElement.textContent =
      itemCount;
  }


  if (summarySubtotal) {

    summarySubtotal.textContent =
      formatNaira(
        subtotal
      );
  }


  if (deliveryFeeElement) {

    deliveryFeeElement.textContent =
      formatNaira(
        deliveryFee
      );
  }


  if (summaryTotal) {

    summaryTotal.textContent =
      formatNaira(
        total
      );
  }


  if (confirmAmount) {

    confirmAmount.textContent =
      formatNaira(
        total
      );
  }
}


/* =========================================================
   RENDER BANK DETAILS
========================================================= */

function renderBankDetails() {

  const bankName =
    paymentSettings.bankName ||
    "";

  const accountName =
    paymentSettings.accountName ||
    "";

  const accountNumber =
    paymentSettings.accountNumber ||
    "";


  /*
    Support multiple possible IDs
    so this works with the current
    payment.html structure.
  */

  const bankNameElements = [

    document.getElementById(
      "bankName"
    ),

    document.getElementById(
      "paymentBankName"
    )

  ].filter(Boolean);


  const accountNameElements = [

    document.getElementById(
      "accountName"
    ),

    document.getElementById(
      "bankAccountName"
    ),

    document.getElementById(
      "paymentAccountName"
    )

  ].filter(Boolean);


  const accountNumberElements = [

    document.getElementById(
      "accountNumber"
    ),

    document.getElementById(
      "bankAccountNumber"
    ),

    document.getElementById(
      "paymentAccountNumber"
    )

  ].filter(Boolean);


  bankNameElements.forEach(
    element => {

      element.textContent =
        bankName ||
        "Bank details unavailable";

    }
  );


  accountNameElements.forEach(
    element => {

      element.textContent =
        accountName ||
        "Account name unavailable";

    }
  );


  accountNumberElements.forEach(
    element => {

      element.textContent =
        accountNumber ||
        "Account number unavailable";

    }
  );


  /*
    Also update common data attributes
    if the payment HTML uses them.
  */

  const bankNumberInput =
    document.querySelector(
      "[data-bank-account-number]"
    );


  if (bankNumberInput) {

    bankNumberInput.textContent =
      accountNumber;
  }


  const copyButton =
    document.getElementById(
      "copyAccountButton"
    );


  if (copyButton) {

    copyButton.disabled =
      !accountNumber;

    copyButton.style.opacity =
      accountNumber
        ? "1"
        : "0.55";
  }


  /*
    Log the values during development.
    This makes it easy to confirm that the
    admin settings reached the payment page.
  */

  console.log(
    "BANK DETAILS RENDERED:",
    {
      bankName,
      accountName,
      accountNumber
    }
  );
}


/* =========================================================
   PAYMENT INSTRUCTIONS
========================================================= */

function renderPaymentInstructions() {

  const instructions =
    String(
      paymentSettings.paymentInstructions ||
      ""
    ).trim();


  const elements = [

    document.getElementById(
      "paymentInstructions"
    ),

    document.getElementById(
      "bankInstructions"
    ),

    document.getElementById(
      "paymentInstruction"
    )

  ].filter(Boolean);


  elements.forEach(
    element => {

      if (!instructions) {

        element.textContent =
          "";

        element.style.display =
          "none";

        return;
      }


      element.textContent =
        instructions;

      element.style.display =
        "";
    }
  );
}


/* =========================================================
   CUSTOMER DETAILS
========================================================= */

function renderCustomerDetails() {

  const name =
    checkoutData.customerName ||
    "�";


  const phone =
    checkoutData.customerPhone ||
    "�";


  const email =
    checkoutData.customerEmail ||
    "�";


  const address =
    checkoutData.deliveryAddress ||
    "�";


  const location = [

    checkoutData.deliveryCity,

    checkoutData.deliveryState

  ]
    .filter(Boolean)
    .join(", ") ||
    "�";


  const elements = {

    customerName:
      name,

    customerPhone:
      phone,

    customerEmail:
      email,

    customerAddress:
      address,

    customerLocation:
      location

  };


  Object.entries(
    elements
  ).forEach(
    (
      [
        id,
        value
      ]
    ) => {

      const element =
        document.getElementById(
          id
        );


      if (element) {

        element.textContent =
          value;
      }
    }
  );
}


/* =========================================================
   PAYMENT METHOD VISIBILITY
========================================================= */

function updatePaymentMethodVisibility() {

  const transferButton =
    document.getElementById(
      "transferMethod"
    );


  const codButton =
    document.getElementById(
      "codMethod"
    );


  if (transferButton) {

    transferButton.style.display =
      paymentSettings.bankTransferEnabled
        ? ""
        : "none";
  }


  if (codButton) {

    codButton.style.display =
      paymentSettings.cashOnDeliveryEnabled
        ? ""
        : "none";
  }


  if (
    selectedPayment ===
      "bank_transfer" &&
    !paymentSettings.bankTransferEnabled
  ) {

    selectedPayment =
      "";
  }


  if (
    selectedPayment ===
      "cash_on_delivery" &&
    !paymentSettings.cashOnDeliveryEnabled
  ) {

    selectedPayment =
      "";
  }


  if (!selectedPayment) {

    if (
      paymentSettings.bankTransferEnabled
    ) {

      choosePayment(
        "bank_transfer"
      );

      return;
    }


    if (
      paymentSettings.cashOnDeliveryEnabled
    ) {

      choosePayment(
        "cash_on_delivery"
      );

      return;
    }
  }


  if (
    !paymentSettings.bankTransferEnabled &&
    !paymentSettings.cashOnDeliveryEnabled
  ) {

    showNoPaymentMethodsMessage();
  }
}


/* =========================================================
   NO PAYMENT METHODS
========================================================= */

function showNoPaymentMethodsMessage() {

  const existing =
    document.getElementById(
      "noPaymentMethodsMessage"
    );


  if (existing) {
    return;
  }


  const message =
    document.createElement(
      "div"
    );


  message.id =
    "noPaymentMethodsMessage";


  message.textContent =
    "No payment methods are currently available. Please try again later.";


  message.style.cssText = `
    margin:12px 0;
    padding:12px 14px;
    border-radius:10px;
    background:#fff1f1;
    border:1px solid #ffd4d4;
    color:#b42318;
    font-size:13px;
    line-height:1.45;
  `;


  const target =
    document.getElementById(
      "transferMethod"
    ) ||
    document.getElementById(
      "codMethod"
    );


  if (
    target &&
    target.parentElement
  ) {

    target.parentElement.insertBefore(
      message,
      target
    );
  }
}


/* =========================================================
   PAYMENT METHODS
========================================================= */

function setupPaymentMethods() {

  const transferButton =
    document.getElementById(
      "transferMethod"
    );


  const codButton =
    document.getElementById(
      "codMethod"
    );


  if (transferButton) {

    transferButton.addEventListener(
      "click",
      () => {

        choosePayment(
          "bank_transfer"
        );
      }
    );
  }


  if (codButton) {

    codButton.addEventListener(
      "click",
      () => {

        choosePayment(
          "cash_on_delivery"
        );
      }
    );
  }
}


/* =========================================================
   CHOOSE PAYMENT
========================================================= */

function choosePayment(
  method
) {

  if (
    method ===
      "bank_transfer" &&
    !paymentSettings.bankTransferEnabled
  ) {

    showToast(
      "Bank transfer is currently unavailable."
    );


    return;
  }


  if (
    method ===
      "cash_on_delivery" &&
    !paymentSettings.cashOnDeliveryEnabled
  ) {

    showToast(
      "Cash on Delivery is currently unavailable."
    );


    return;
  }


  selectedPayment =
    method;


  const transferButton =
    document.getElementById(
      "transferMethod"
    );


  const codButton =
    document.getElementById(
      "codMethod"
    );


  const transferPanel =
    document.getElementById(
      "transferPanel"
    );


  const codPanel =
    document.getElementById(
      "codPanel"
    );


  if (transferButton) {

    transferButton.classList.toggle(
      "active",
      method ===
        "bank_transfer"
    );
  }


  if (codButton) {

    codButton.classList.toggle(
      "active",
      method ===
        "cash_on_delivery"
    );
  }


  if (transferPanel) {

    transferPanel.classList.toggle(
      "show",
      method ===
        "bank_transfer"
    );
  }


  if (codPanel) {

    codPanel.classList.toggle(
      "show",
      method ===
        "cash_on_delivery"
    );
  }


  const confirmNote =
    document.getElementById(
      "confirmNote"
    );


  if (confirmNote) {

    if (
      method ===
        "bank_transfer"
    ) {

      if (screenshotFile) {

        confirmNote.textContent =
          "Transfer screenshot attached. You can now confirm your order.";

      } else {

        confirmNote.textContent =
          "Complete your transfer and upload the screenshot to continue.";
      }

    } else {

      confirmNote.textContent =
        "Your order will be confirmed with Cash on Delivery.";
    }
  }


  updateConfirmButton();
}


/* =========================================================
   SCREENSHOT UPLOAD
========================================================= */

function setupScreenshotUpload() {

  const input =
    document.getElementById(
      "transferScreenshot"
    );


  const preview =
    document.getElementById(
      "screenshotPreview"
    );


  const previewImage =
    document.getElementById(
      "previewImage"
    );


  const previewFileName =
    document.getElementById(
      "previewFileName"
    );


  const previewFileSize =
    document.getElementById(
      "previewFileSize"
    );


  const removeButton =
    document.getElementById(
      "removeScreenshot"
    );


  if (!input) {
    return;
  }


  input.addEventListener(
    "change",
    () => {

      const file =
        input.files?.[0];


      if (!file) {
        return;
      }


      if (
        !file.type.startsWith(
          "image/"
        )
      ) {

        showToast(
          "Please select an image."
        );


        input.value =
          "";


        return;
      }


      if (
        file.size >
        10 * 1024 * 1024
      ) {

        showToast(
          "Image must be smaller than 10MB."
        );


        input.value =
          "";


        return;
      }


      screenshotFile =
        file;


      if (previewImage) {

        const reader =
          new FileReader();


        reader.onload =
          event => {

            previewImage.src =
              event.target.result;
          };


        reader.readAsDataURL(
          file
        );
      }


      if (previewFileName) {

        previewFileName.textContent =
          file.name;
      }


      if (previewFileSize) {

        previewFileSize.textContent =
          formatFileSize(
            file.size
          );
      }


      if (preview) {

        preview.classList.add(
          "show"
        );
      }


      const confirmNote =
        document.getElementById(
          "confirmNote"
        );


      if (
        selectedPayment ===
          "bank_transfer" &&
        confirmNote
      ) {

        confirmNote.textContent =
          "Transfer screenshot attached. You can now confirm your order.";
      }


      updateConfirmButton();
    }
  );


  if (removeButton) {

    removeButton.addEventListener(
      "click",
      () => {

        screenshotFile =
          null;


        input.value =
          "";


        if (previewImage) {

          previewImage.src =
            "";
        }


        if (previewFileName) {

          previewFileName.textContent =
            "";
        }


        if (previewFileSize) {

          previewFileSize.textContent =
            "";
        }


        if (preview) {

          preview.classList.remove(
            "show"
          );
        }


        const confirmNote =
          document.getElementById(
            "confirmNote"
          );


        if (
          selectedPayment ===
            "bank_transfer" &&
          confirmNote
        ) {

          confirmNote.textContent =
            "Complete your transfer and upload the screenshot to continue.";
        }


        updateConfirmButton();
      }
    );
  }
}


/* =========================================================
   COPY ACCOUNT NUMBER
========================================================= */

function setupCopyButton() {

  const button =
    document.getElementById(
      "copyAccountButton"
    );


  if (!button) {
    return;
  }


  button.addEventListener(
    "click",
    async () => {

      const accountNumber =
        paymentSettings.accountNumber;


      if (!accountNumber) {

        showToast(
          "Bank account details are not currently available."
        );


        return;
      }


      try {

        await navigator.clipboard.writeText(
          accountNumber
        );


        showToast(
          "Account number copied."
        );

      } catch (error) {

        /*
          Fallback for browsers where
          navigator.clipboard is unavailable.
        */

        try {

          const temporary =
            document.createElement(
              "textarea"
            );


          temporary.value =
            accountNumber;


          temporary.style.position =
            "fixed";

          temporary.style.opacity =
            "0";


          document.body.appendChild(
            temporary
          );


          temporary.select();


          document.execCommand(
            "copy"
          );


          temporary.remove();


          showToast(
            "Account number copied."
          );

        } catch (fallbackError) {

          showToast(
            "Unable to copy account number."
          );
        }
      }
    }
  );
}


/* =========================================================
   CONFIRM BUTTON
========================================================= */

function setupConfirmButton() {

  const button =
    document.getElementById(
      "confirmOrderButton"
    );


  if (!button) {
    return;
  }


  button.addEventListener(
    "click",
    confirmOrder
  );
}


/* =========================================================
   UPDATE CONFIRM BUTTON
========================================================= */

function updateConfirmButton() {

  const button =
    document.getElementById(
      "confirmOrderButton"
    );


  if (!button) {
    return;
  }


  let canConfirm =
    false;


  if (
    selectedPayment ===
      "cash_on_delivery" &&
    paymentSettings.cashOnDeliveryEnabled
  ) {

    canConfirm =
      true;
  }


  if (
    selectedPayment ===
      "bank_transfer" &&
    paymentSettings.bankTransferEnabled &&
    screenshotFile
  ) {

    canConfirm =
      true;
  }


  button.disabled =
    !canConfirm ||
    isProcessing;
}


/* =========================================================
   CONFIRM ORDER
========================================================= */

async function confirmOrder() {

  if (isProcessing) {
    return;
  }


  /*
    Re-check authentication.
  */

  const {
    data,
    error
  } =
    await supabaseClient
      .auth
      .getSession();


  if (
    error ||
    !data?.session?.user
  ) {

    showToast(
      "Your session has expired. Please log in again."
    );


    setTimeout(
      () => {

        window.location.href =
          "login.html";

      },
      900
    );


    return;
  }


  currentUser =
    data.session.user;


  /*
    Reload the current shared cart.

    Nothing is removed here.
  */

  cart =
    getCart();


  checkoutData =
    getCheckoutData();


  if (!cart.length) {

    showToast(
      "Your cart is empty."
    );


    return;
  }


  if (!selectedPayment) {

    showToast(
      "Please choose a payment method."
    );


    return;
  }


  if (
    selectedPayment ===
      "bank_transfer"
  ) {

    if (
      !paymentSettings.bankTransferEnabled
    ) {

      showToast(
        "Bank transfer is currently unavailable."
      );


      return;
    }


    if (!screenshotFile) {

      showToast(
        "Please upload your transfer screenshot."
      );


      return;
    }
  }


  if (
    selectedPayment ===
      "cash_on_delivery" &&
    !paymentSettings.cashOnDeliveryEnabled
  ) {

    showToast(
      "Cash on Delivery is currently unavailable."
    );


    return;
  }


  /*
    Make sure checkout data belongs
    to the currently logged-in customer.
  */

  if (
    checkoutData.customerId &&
    checkoutData.customerId !==
      currentUser.id
  ) {

    showToast(
      "Checkout session does not belong to this account."
    );


    return;
  }


  isProcessing =
    true;


  updateConfirmButton();


  const button =
    document.getElementById(
      "confirmOrderButton"
    );


  const originalText =
    button?.textContent ||
    "Confirm Order";


  if (button) {

    button.textContent =
      "Processing...";
  }


  try {

    /*
      Calculate final values
      from the shared cart.
    */

    const subtotal =
      getSubtotal();


    const deliveryFee =
      Number(
        checkoutData.deliveryFee
      ) || 0;


    const total =
      subtotal +
      deliveryFee;


    if (total <= 0) {

      throw new Error(
        "Invalid order total."
      );
    }


    /*
      Generate order ID.
    */

    const orderId =
      createOrderId();


    let transferScreenshotPath =
      null;


    /* -----------------------------------------
       UPLOAD TRANSFER SCREENSHOT
    ----------------------------------------- */

    if (
      selectedPayment ===
        "bank_transfer" &&
      screenshotFile
    ) {

      const extension =
        getFileExtension(
          screenshotFile.name
        );


      const filePath =
        `orders/${currentUser.id}/${orderId}/${Date.now()}.${extension}`;


      const uploadResult =
        await supabaseClient
          .storage
          .from(
            TRANSFER_BUCKET
          )
          .upload(
            filePath,
            screenshotFile,
            {
              cacheControl:
                "3600",

              upsert:
                false,

              contentType:
                screenshotFile.type
            }
          );


      if (
        uploadResult.error
      ) {

        throw new Error(
          "Screenshot upload failed: " +
          uploadResult.error.message
        );
      }


      /*
        The bucket is private.

        Store the storage path rather than
        creating a public URL.
      */

      transferScreenshotPath =
        filePath;
    }


    /* -----------------------------------------
       CUSTOMER DETAILS
    ----------------------------------------- */

    const customerName =
      checkoutData.customerName ||
      "";


    const customerPhone =
      checkoutData.customerPhone ||
      "";


    const customerEmail =
      checkoutData.customerEmail ||
      "";


    const deliveryAddress =
      checkoutData.deliveryAddress ||
      "";


    const deliveryCity =
      checkoutData.deliveryCity ||
      "";


    const deliveryState =
      checkoutData.deliveryState ||
      "";


    if (!customerName) {

      throw new Error(
        "Customer name is missing."
      );
    }


    if (!customerPhone) {

      throw new Error(
        "Customer phone number is missing."
      );
    }


    if (!customerEmail) {

      throw new Error(
        "Customer email is missing."
      );
    }


    if (!deliveryAddress) {

      throw new Error(
        "Delivery address is missing."
      );
    }


    if (!deliveryCity) {

      throw new Error(
        "Delivery city is missing."
      );
    }


    if (!deliveryState) {

      throw new Error(
        "Delivery state is missing."
      );
    }


    /* -----------------------------------------
       CREATE ORDER
    ----------------------------------------- */

    const orderPayload = {

      id:
        orderId,

      customer_id:
        currentUser.id,

      customer_name:
        customerName,

      customer_phone:
        customerPhone,

      customer_email:
        customerEmail,

      delivery_address:
        deliveryAddress,

      delivery_city:
        deliveryCity,

      delivery_state:
        deliveryState,

      payment_method:
        selectedPayment,

      payment_status:
        "pending",

      order_status:
        "pending",

      subtotal:
        subtotal,

      delivery_fee:
        deliveryFee,

      total:
        total,

      transfer_screenshot:
        transferScreenshotPath,

      admin_note:
        null

    };


    const orderResult =
      await supabaseClient
        .from(
          "orders"
        )
        .insert(
          orderPayload
        )
        .select()
        .single();


    if (
      orderResult.error
    ) {

      throw new Error(
        "Order creation failed: " +
        orderResult.error.message
      );
    }


    /* -----------------------------------------
       CREATE ORDER ITEMS
    ----------------------------------------- */

    const orderItems =
      cart.map(
        item => {

          const quantity =
            Math.max(
              1,
              Number(
                item.quantity
              ) || 1
            );


          const unitPrice =
            Number(
              item.unit_price
            ) || 0;


          return {

            order_id:
              orderId,

            product_id:
              item.product_id ||
              null,

            product_name:
              item.product_name ||
              item.name ||
              "",

            product_image:
              item.product_image ||
              item.image_url ||
              item.image ||
              "",

            quantity:
              quantity,

            unit_price:
              unitPrice,

            subtotal:
              unitPrice *
              quantity,

            variant:
              item.variant ||
              null

          };

        }
      );


    const itemsResult =
      await supabaseClient
        .from(
          "order_items"
        )
        .insert(
          orderItems
        );


    if (
      itemsResult.error
    ) {

      /*
        The order was created, but the items
        failed.

        DO NOT clear the cart.
      */

      throw new Error(
        "Order items could not be saved: " +
        itemsResult.error.message
      );
    }


    /* -----------------------------------------
       SAVE LAST ORDER
    ----------------------------------------- */

    const lastOrderKey =
      getLastOrderKey();


    if (lastOrderKey) {

      localStorage.setItem(
        lastOrderKey,
        orderId
      );
    }


    /* -----------------------------------------
       CLEAR SHARED CART
    -----------------------------------------

       ONLY after:

       1. orders insert succeeded
       2. order_items insert succeeded
    */

    localStorage.removeItem(
      CART_KEY
    );


    window.dispatchEvent(
      new Event(
        "marketHubCartUpdated"
      )
    );


    /*
      Keep checkout data available for
      the success screen/order page.
    */

    showOrderSuccess(
      orderId
    );


  } catch (error) {

    console.error(
      "ORDER ERROR:",
      error
    );


    /*
      The cart is intentionally NOT cleared
      when any step fails.
    */

    showToast(
      error.message ||
      "Unable to place order."
    );


    if (button) {

      button.textContent =
        originalText;
    }


  } finally {

    isProcessing =
      false;


    updateConfirmButton();
  }
}


/* =========================================================
   ORDER ID
========================================================= */

function createOrderId() {

  const now =
    new Date();


  const datePart =
    now.getFullYear() +

    String(
      now.getMonth() + 1
    ).padStart(
      2,
      "0"
    ) +

    String(
      now.getDate()
    ).padStart(
      2,
      "0"
    ) +

    String(
      now.getHours()
    ).padStart(
      2,
      "0"
    ) +

    String(
      now.getMinutes()
    ).padStart(
      2,
      "0"
    ) +

    String(
      now.getSeconds()
    ).padStart(
      2,
      "0"
    );


  const random =
    Math.random()
      .toString(36)
      .substring(
        2,
        7
      )
      .toUpperCase();


  return (
    `MH-${datePart}-${random}`
  );
}


/* =========================================================
   NAVIGATION
========================================================= */

function setupNavigation() {

  const backButton =
    document.getElementById(
      "backButton"
    );


  const editButton =
    document.getElementById(
      "editCheckoutButton"
    );


  if (backButton) {

    backButton.addEventListener(
      "click",
      () => {

        /*
          Going back does NOT clear the cart.
        */

        window.location.href =
          "checkout.html";
      }
    );
  }


  if (editButton) {

    editButton.addEventListener(
      "click",
      () => {

        window.location.href =
          "checkout.html";
      }
    );
  }
}


/* =========================================================
   SUCCESS MESSAGE
========================================================= */

function showOrderSuccess(
  orderId
) {

  const overlay =
    document.getElementById(
      "orderSuccess"
    );


  const orderIdElement =
    document.getElementById(
      "successOrderId"
    );


  const viewOrderButton =
    document.getElementById(
      "viewOrderButton"
    );


  const continueShoppingButton =
    document.getElementById(
      "continueShoppingButton"
    );


  if (orderIdElement) {

    orderIdElement.textContent =
      orderId;
  }


  renderOrderConfirmationMessage();


  if (overlay) {

    overlay.classList.add(
      "show"
    );
  }


  if (viewOrderButton) {

    viewOrderButton.onclick =
      () => {

        window.location.href =
          "orders.html";
      };
  }


  if (continueShoppingButton) {

    continueShoppingButton.onclick =
      () => {

        window.location.href =
          "index.html";
      };
  }
}


/* =========================================================
   CONFIRMATION MESSAGE
========================================================= */

function renderOrderConfirmationMessage() {

  const message =
    String(
      paymentSettings
        .orderConfirmationMessage ||
      ""
    ).trim();


  const existing =
    document.getElementById(
      "marketHubOrderConfirmationMessage"
    );


  if (!message) {

    if (existing) {
      existing.remove();
    }


    return;
  }


  let element =
    existing;


  if (!element) {

    element =
      document.createElement(
        "div"
      );


    element.id =
      "marketHubOrderConfirmationMessage";


    element.style.cssText = `
      margin:14px 0 16px;
      padding:13px 15px;
      border-radius:12px;
      background:#fff7ef;
      border:1px solid #ffd9b8;
      color:#7a3d00;
      font-size:13px;
      line-height:1.55;
      text-align:center;
      white-space:pre-line;
      box-sizing:border-box;
    `;


    const button =
      document.getElementById(
        "viewOrderButton"
      );


    if (
      button &&
      button.parentElement
    ) {

      button.parentElement.insertBefore(
        element,
        button
      );

    } else if (
      overlayExists()
    ) {

      document
        .getElementById(
          "orderSuccess"
        )
        .appendChild(
          element
        );
    }
  }


  element.textContent =
    message;
}


/* =========================================================
   OVERLAY CHECK
========================================================= */

function overlayExists() {

  return !!document.getElementById(
    "orderSuccess"
  );
}


/* =========================================================
   AUTH STATE
========================================================= */

supabaseClient.auth.onAuthStateChange(
  (
    event,
    session
  ) => {

    const nextUser =
      session?.user ||
      null;


    if (!nextUser) {

      currentUser =
        null;

      cart =
        [];

      checkoutData =
        {};

      selectedPayment =
        "";

      screenshotFile =
        null;


      showLoginRequired();


      return;
    }


    if (
      currentUser?.id ===
      nextUser.id
    ) {

      return;
    }


    currentUser =
      nextUser;


    cart =
      getCart();


    checkoutData =
      getCheckoutData();


    if (cart.length) {

      loadPaymentSettings()
        .then(
          () => {

            setupPage();
          }
        );

    } else {

      showEmptyPayment();
    }
  }
);