/* =========================================================
   MARKET HUB — CHECKOUT
   Current Cart → Checkout → Payment
========================================================= */


/* =========================================================
   SUPABASE
========================================================= */

const SUPABASE_URL =
  "https://ccalqnjtkbkinqunmsjp.supabase.co";

const SUPABASE_ANON_KEY =
  "sb_publishable_MQCLuqLfDe-QRZDLeDjHjw_qyjsPaoj";

const supabaseClient =
  window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
  );


/* =====================================
   AUTHENTICATION GUARD
===================================== */

async function checkCustomerAuthentication() {

  try {

    const {
      data,
      error
    } = await supabaseClient.auth.getSession();


    if (error) {

      console.error(
        "AUTH SESSION ERROR:",
        error
      );

      window.location.replace(
        "login.html"
      );

      return false;
    }


    if (!data?.session) {

      window.location.replace(
        "login.html"
      );

      return false;
    }


    return true;


  } catch (error) {

    console.error(
      "AUTHENTICATION ERROR:",
      error
    );

    window.location.replace(
      "login.html"
    );

    return false;
  }
}


/* =========================================================
   CART KEY
   IMPORTANT:
   This MUST stay the same as Cart/Home/Product.
========================================================= */

const CART_KEY =
  "marketHubCart";


const CHECKOUT_KEY_PREFIX =
  "marketHubCheckout_";


/* =========================================================
   STATE
========================================================= */

let currentUser = null;

let cart = [];

let subtotal = 0;

let deliveryFee = 0;

let total = 0;

let marketHubSettings = null;

let toastTimer = null;


/* =========================================================
   GET CHECKOUT STORAGE KEY
========================================================= */

function getCheckoutKey() {

  if (!currentUser) {
    return null;
  }

  return (
    CHECKOUT_KEY_PREFIX +
    currentUser.id
  );
}


/* =========================================================
   AUTH
========================================================= */

async function loadCurrentUser() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient.auth.getSession();


    if (error) {
      throw error;
    }


    currentUser =
      data?.session?.user ||
      null;


    if (!currentUser) {

      showLoginState();

      return false;
    }


    return true;

  } catch (error) {

    console.error(
      "CHECKOUT AUTH ERROR:",
      error
    );


    currentUser =
      null;


    showLoginState();


    return false;
  }
}


/* =========================================================
   AUTH STATE
========================================================= */

supabaseClient.auth.onAuthStateChange(
  (
    event,
    session
  ) => {

    const nextUser =
      session?.user ||
      null;


    if (
      currentUser?.id ===
      nextUser?.id
    ) {

      return;
    }


    currentUser =
      nextUser;


    if (!currentUser) {

      showLoginState();

      return;
    }


    initCheckout();
  }
);


/* =========================================================
   LOGIN STATE
========================================================= */

function showLoginState() {

  const emptyCheckout =
    document.getElementById(
      "emptyCheckout"
    );


  const checkoutContent =
    document.getElementById(
      "checkoutContent"
    );


  if (checkoutContent) {

    checkoutContent.style.display =
      "none";
  }


  if (!emptyCheckout) {
    return;
  }


  emptyCheckout.style.display =
    "block";


  const heading =
    emptyCheckout.querySelector(
      "h1"
    );


  const paragraph =
    emptyCheckout.querySelector(
      "p"
    );


  if (heading) {

    heading.textContent =
      "Login required";
  }


  if (paragraph) {

    paragraph.textContent =
      "Please log in to continue to checkout.";
  }


  const button =
    document.getElementById(
      "emptyShopButton"
    );


  if (button) {

    button.textContent =
      "Go to Login";


    button.onclick =
      () => {

        window.location.href =
          "login.html";
      };
  }
}


/* =========================================================
   LOAD CART
   IMPORTANT:
   Read the SAME cart used by cart.html,
   index.html and product.html.
========================================================= */

function loadCart() {

  try {

    const saved =
      localStorage.getItem(
        CART_KEY
      );


    if (!saved) {

      return [];
    }


    const parsed =
      JSON.parse(
        saved
      );


    if (!Array.isArray(parsed)) {

      return [];
    }


    return parsed.filter(
      item => {

        return (
          item &&
          item.product_id
        );
      }
    );

  } catch (error) {

    console.error(
      "CHECKOUT CART ERROR:",
      error
    );


    return [];
  }
}


/* =========================================================
   DO NOT MODIFY CART HERE
=========================================================

   IMPORTANT:

   Checkout NEVER removes products.

   Checkout NEVER clears the cart.

   Checkout NEVER changes quantity.

   Checkout NEVER deletes cart storage.

   Cart is only cleared after successful
   order/payment completion from the proper
   order flow.
========================================================= */


/* =========================================================
   FORMAT NAIRA
========================================================= */

function formatNaira(
  value
) {

  return new Intl.NumberFormat(
    "en-NG",
    {
      style:
        "currency",

      currency:
        "NGN",

      maximumFractionDigits:
        0
    }
  ).format(
    Number(value) || 0
  );
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(
  value
) {

  return String(
    value ?? ""
  )
    .replace(
      /&/g,
      "&amp;"
    )
    .replace(
      /</g,
      "&lt;"
    )
    .replace(
      />/g,
      "&gt;"
    )
    .replace(
      /"/g,
      "&quot;"
    )
    .replace(
      /'/g,
      "&#039;"
    );
}


/* =========================================================
   PRODUCT IMAGE
========================================================= */

function getProductImage(
  item
) {

  if (
    item.product_image
  ) {

    return item.product_image;
  }


  if (
    item.image_url
  ) {

    return item.image_url;
  }


  if (
    item.image
  ) {

    return item.image;
  }


  /*
    Some older cart items may contain
    an images array.
  */

  if (
    Array.isArray(
      item.images
    ) &&
    item.images.length
  ) {

    return item.images[0];
  }


  return "";
}


/* =========================================================
   TOAST
========================================================= */

function showToast(
  message
) {

  const toast =
    document.getElementById(
      "toast"
    );


  if (!toast) {
    return;
  }


  toast.textContent =
    message;


  toast.classList.add(
    "show"
  );


  clearTimeout(
    toastTimer
  );


  toastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2800
    );
}


/* =========================================================
   LOAD PUBLIC SETTINGS
========================================================= */

async function loadMarketHubSettings() {

  try {

    const {
      data,
      error
    } =
      await supabaseClient
        .from(
          "market_hub_public_settings"
        )
        .select(`
          id,
          store_name,
          store_description,
          delivery_enabled,
          delivery_fee,
          free_delivery_threshold,
          delivery_areas,
          delivery_estimate,
          minimum_order_amount,
          maintenance_mode,
          order_confirmation_message
        `)
        .eq(
          "id",
          1
        )
        .maybeSingle();


    if (error) {

      console.error(
        "PUBLIC SETTINGS ERROR:",
        error
      );


      marketHubSettings =
        null;


      return false;
    }


    marketHubSettings =
      data ||
      null;


    return true;

  } catch (error) {

    console.error(
      "SETTINGS ERROR:",
      error
    );


    marketHubSettings =
      null;


    return false;
  }
}


/* =========================================================
   STORE CHECK
========================================================= */

function checkStoreAvailability() {

  if (!marketHubSettings) {

    return true;
  }


  if (
    marketHubSettings.maintenance_mode
  ) {

    showToast(
      "MarketHub is temporarily under maintenance."
    );


    const button =
      document.querySelector(
        '#checkoutForm button[type="submit"]'
      );


    if (button) {

      button.disabled =
        true;
    }


    return false;
  }


  return true;
}


/* =========================================================
   RENDER DELIVERY INFORMATION
========================================================= */

function renderDeliveryInformation() {

  const element =
    document.getElementById(
      "marketHubDeliveryInfo"
    );


  if (!element) {
    return;
  }


  if (!marketHubSettings) {

    element.style.display =
      "none";

    return;
  }


  const information = [];


  if (
    marketHubSettings.delivery_enabled
  ) {

    if (
      marketHubSettings.delivery_estimate
    ) {

      information.push(
        `Delivery: ${
          escapeHTML(
            marketHubSettings.delivery_estimate
          )
        }`
      );
    }


    if (
      marketHubSettings.delivery_areas
    ) {

      information.push(
        `Areas: ${
          escapeHTML(
            marketHubSettings.delivery_areas
          )
        }`
      );
    }
  }


  if (!information.length) {

    element.style.display =
      "none";

    return;
  }


  element.style.display =
    "block";


  element.innerHTML = `

    <strong>
      Delivery Information
    </strong>

    <span>
      ${information.join(" • ")}
    </span>

  `;
}


/* =========================================================
   CALCULATE TOTALS
========================================================= */

function calculateTotals() {

  subtotal =
    0;


  cart.forEach(
    item => {

      const quantity =
        Math.max(
          1,
          Number(
            item.quantity
          ) || 1
        );


      const unitPrice =
        Math.max(
          0,
          Number(
            item.unit_price
          ) || 0
        );


      subtotal +=
        unitPrice *
        quantity;
    }
  );


  deliveryFee =
    0;


  if (
    marketHubSettings &&
    marketHubSettings.delivery_enabled
  ) {

    const configuredFee =
      Number(
        marketHubSettings.delivery_fee
      ) || 0;


    const freeThreshold =
      Number(
        marketHubSettings.free_delivery_threshold
      ) || 0;


    if (
      freeThreshold > 0 &&
      subtotal >= freeThreshold
    ) {

      deliveryFee =
        0;

    } else {

      deliveryFee =
        configuredFee;
    }
  }


  total =
    subtotal +
    deliveryFee;


  updateTotalsDisplay();
}


/* =========================================================
   UPDATE TOTALS
========================================================= */

function updateTotalsDisplay() {

  const subtotalElement =
    document.getElementById(
      "subtotal"
    );


  const deliveryElement =
    document.getElementById(
      "deliveryFee"
    );


  const totalElement =
    document.getElementById(
      "checkoutTotal"
    );


  if (subtotalElement) {

    subtotalElement.textContent =
      formatNaira(
        subtotal
      );
  }


  if (deliveryElement) {

    if (
      marketHubSettings &&
      !marketHubSettings.delivery_enabled
    ) {

      deliveryElement.textContent =
        "Unavailable";

    } else if (
      marketHubSettings &&
      Number(
        marketHubSettings.free_delivery_threshold
      ) > 0 &&
      subtotal >=
        Number(
          marketHubSettings.free_delivery_threshold
        )
    ) {

      deliveryElement.textContent =
        "FREE";

    } else {

      deliveryElement.textContent =
        formatNaira(
          deliveryFee
        );
    }
  }


  if (totalElement) {

    totalElement.textContent =
      formatNaira(
        total
      );
  }
}


/* =========================================================
   RENDER CART PRODUCTS
========================================================= */

function renderItems() {

  const container =
    document.getElementById(
      "checkoutItems"
    );


  if (!container) {
    return;
  }


  container.innerHTML =
    "";


  if (!cart.length) {

    return;
  }


  cart.forEach(
    (
      item,
      index
    ) => {

      const quantity =
        Math.max(
          1,
          Number(
            item.quantity
          ) || 1
        );


      const unitPrice =
        Math.max(
          0,
          Number(
            item.unit_price
          ) || 0
        );


      const itemTotal =
        unitPrice *
        quantity;


      const productName =
        item.product_name ||
        item.name ||
        "Product";


      const image =
        getProductImage(
          item
        );


      const variant =
        item.variant ||
        "";


      let imageHTML;


      if (image) {

        imageHTML = `

          <img
            src="${escapeHTML(
              image
            )}"
            alt="${escapeHTML(
              productName
            )}"
            class="checkout-item-image"
            loading="lazy"
            onerror="this.style.display='none';"
          >

        `;

      } else {

        imageHTML = `

          <div class="
            checkout-item-image
            checkout-item-placeholder
          ">
            M
          </div>

        `;
      }


      container.insertAdjacentHTML(
        "beforeend",
        `

          <div
            class="checkout-item"
            data-cart-index="${index}"
          >

            ${imageHTML}


            <div class="checkout-item-info">

              <strong>
                ${escapeHTML(
                  productName
                )}
              </strong>


              ${
                variant
                  ? `
                    <span>
                      ${escapeHTML(
                        variant
                      )}
                    </span>
                  `
                  : ""
              }


              <span>
                Qty ${quantity}
                ·
                ${formatNaira(
                  unitPrice
                )} each
              </span>

            </div>


            <strong class="checkout-item-total">

              ${formatNaira(
                itemTotal
              )}

            </strong>

          </div>

        `
      );

    }
  );
}


/* =========================================================
   LOAD SAVED CUSTOMER DETAILS
========================================================= */

function loadSavedCheckout() {

  const key =
    getCheckoutKey();


  if (!key) {
    return;
  }


  try {

    const saved =
      localStorage.getItem(
        key
      );


    if (!saved) {
      return;
    }


    const data =
      JSON.parse(
        saved
      );


    if (!data) {
      return;
    }


    const fields = {

      customerName:
        data.customerName,

      customerPhone:
        data.customerPhone,

      customerEmail:
        data.customerEmail,

      deliveryAddress:
        data.deliveryAddress,

      deliveryCity:
        data.deliveryCity,

      deliveryState:
        data.deliveryState

    };


    Object.entries(
      fields
    ).forEach(
      (
        [
          id,
          value
        ]
      ) => {

        const element =
          document.getElementById(
            id
          );


        if (
          element &&
          value !== undefined &&
          value !== null
        ) {

          element.value =
            value;
        }
      }
    );

  } catch (error) {

    console.error(
      "SAVED CHECKOUT ERROR:",
      error
    );
  }
}


/* =========================================================
   CLEAR FORM ERRORS
========================================================= */

function clearErrors() {

  document
    .querySelectorAll(
      ".field-error"
    )
    .forEach(
      element => {

        element.textContent =
          "";
      }
    );
}


/* =========================================================
   SET FIELD ERROR
========================================================= */

function setError(
  id,
  message
) {

  const element =
    document.getElementById(
      id
    );


  if (element) {

    element.textContent =
      message;
  }
}


/* =========================================================
   VALIDATE FORM
========================================================= */

function validateForm() {

  clearErrors();


  let valid =
    true;


  const customerName =
    document
      .getElementById(
        "customerName"
      )
      ?.value
      .trim() ||
    "";


  const customerPhone =
    document
      .getElementById(
        "customerPhone"
      )
      ?.value
      .trim() ||
    "";


  const customerEmail =
    document
      .getElementById(
        "customerEmail"
      )
      ?.value
      .trim() ||
    "";


  const deliveryAddress =
    document
      .getElementById(
        "deliveryAddress"
      )
      ?.value
      .trim() ||
    "";


  const deliveryCity =
    document
      .getElementById(
        "deliveryCity"
      )
      ?.value
      .trim() ||
    "";


  const deliveryState =
    document
      .getElementById(
        "deliveryState"
      )
      ?.value
      .trim() ||
    "";


  if (!customerName) {

    setError(
      "customerNameError",
      "Enter your full name."
    );


    valid =
      false;
  }


  if (!customerPhone) {

    setError(
      "customerPhoneError",
      "Enter your phone number."
    );


    valid =
      false;
  }


  if (!customerEmail) {

    setError(
      "customerEmailError",
      "Enter your email address."
    );


    valid =
      false;

  } else if (
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/
      .test(
        customerEmail
      )
  ) {

    setError(
      "customerEmailError",
      "Enter a valid email address."
    );


    valid =
      false;
  }


  if (!deliveryAddress) {

    setError(
      "deliveryAddressError",
      "Enter your delivery address."
    );


    valid =
      false;
  }


  if (!deliveryCity) {

    setError(
      "deliveryCityError",
      "Enter your city."
    );


    valid =
      false;
  }


  if (!deliveryState) {

    setError(
      "deliveryStateError",
      "Enter your state."
    );


    valid =
      false;
  }


  return {

    valid,

    data: {

      customerName,

      customerPhone,

      customerEmail,

      deliveryAddress,

      deliveryCity,

      deliveryState

    }
  };
}


/* =========================================================
   MINIMUM ORDER
========================================================= */

function checkMinimumOrder() {

  const minimum =
    Number(
      marketHubSettings?.minimum_order_amount
    ) || 0;


  if (
    minimum <= 0
  ) {

    return true;
  }


  if (
    subtotal >= minimum
  ) {

    return true;
  }


  showToast(
    `Minimum order amount is ${formatNaira(
      minimum
    )}.`
  );


  return false;
}


/* =========================================================
   CONTINUE TO PAYMENT
========================================================= */

function handleCheckoutSubmit(
  event
) {

  event.preventDefault();


  if (!currentUser) {

    showToast(
      "Please log in first."
    );


    return;
  }


  /*
    IMPORTANT:

    Reload the current shared cart immediately
    before continuing.

    This prevents checkout from using an old
    cart stored in memory.
  */

  cart =
    loadCart();


  if (!cart.length) {

    showToast(
      "Your cart is empty."
    );


    return;
  }


  if (
    !checkStoreAvailability()
  ) {

    return;
  }


  calculateTotals();


  if (
    !checkMinimumOrder()
  ) {

    return;
  }


  const result =
    validateForm();


  if (!result.valid) {

    showToast(
      "Please complete your delivery details."
    );


    return;
  }


  /*
    Save ONLY the checkout information.

    We do NOT touch marketHubCart here.
  */

  const checkoutData = {

    customerId:
      currentUser.id,


    customerName:
      result.data.customerName,


    customerPhone:
      result.data.customerPhone,


    customerEmail:
      result.data.customerEmail,


    deliveryAddress:
      result.data.deliveryAddress,


    deliveryCity:
      result.data.deliveryCity,


    deliveryState:
      result.data.deliveryState,


    subtotal:
      subtotal,


    deliveryFee:
      deliveryFee,


    total:
      total,


    itemCount:
      cart.reduce(
        (
          sum,
          item
        ) => {

          return (
            sum +
            Math.max(
              1,
              Number(
                item.quantity
              ) || 1
            )
          );

        },
        0
      ),


    cart:
      cart,


    savedAt:
      new Date().toISOString()
  };


  const checkoutKey =
    getCheckoutKey();


  if (!checkoutKey) {

    showToast(
      "Unable to save checkout information."
    );


    return;
  }


  try {

    localStorage.setItem(
      checkoutKey,
      JSON.stringify(
        checkoutData
      )
    );

  } catch (error) {

    console.error(
      "CHECKOUT SAVE ERROR:",
      error
    );


    showToast(
      "Unable to save checkout information."
    );


    return;
  }


  const button =
    event.target.querySelector(
      'button[type="submit"]'
    );


  if (button) {

    button.disabled =
      true;


    button.style.opacity =
      "0.7";


    const text =
      button.querySelector(
        "span"
      );


    if (text) {

      text.textContent =
        "Opening Payment...";
    }
  }


  /*
    DO NOT CLEAR CART HERE.

    Payment page will handle payment.
    The cart remains until the order is
    successfully completed.
  */

  setTimeout(
    () => {

      window.location.href =
        "payment.html";

    },
    250
  );
}


/* =========================================================
   BUTTONS
========================================================= */

function setupButtons() {

  const form =
    document.getElementById(
      "checkoutForm"
    );


  if (form) {

    form.addEventListener(
      "submit",
      handleCheckoutSubmit
    );
  }


  const backButton =
    document.getElementById(
      "backButton"
    );


  if (backButton) {

    backButton.addEventListener(
      "click",
      () => {

        /*
          Cart is intentionally untouched.
        */

        window.location.href =
          "cart.html";
      }
    );
  }


  const shopButton =
    document.getElementById(
      "shopButton"
    );


  if (shopButton) {

    shopButton.addEventListener(
      "click",
      () => {

        /*
          Cart is intentionally untouched.
        */

        window.location.href =
          "index.html";
      }
    );
  }


  const emptyShopButton =
    document.getElementById(
      "emptyShopButton"
    );


  if (emptyShopButton) {

    emptyShopButton.addEventListener(
      "click",
      () => {

        window.location.href =
          "index.html";
      }
    );
  }
}


/* =========================================================
   INITIALIZE CHECKOUT
========================================================= */

async function initCheckout() {

  /*
    Check authentication before
    allowing access to checkout.
  */

  const authenticated =
    await checkCustomerAuthentication();


  if (!authenticated) {
    return;
  }


  /*
    Load the authenticated user.
  */

  const userLoaded =
    await loadCurrentUser();


  if (!userLoaded) {
    return;
  }


  /*
    IMPORTANT:
    Always load the current shared cart.
  */

  cart =
    loadCart();


  const emptyCheckout =
    document.getElementById(
      "emptyCheckout"
    );


  const checkoutContent =
    document.getElementById(
      "checkoutContent"
    );


  if (!cart.length) {

    if (checkoutContent) {

      checkoutContent.style.display =
        "none";
    }


    if (emptyCheckout) {

      emptyCheckout.style.display =
        "block";


      const heading =
        emptyCheckout.querySelector(
          "h1"
        );


      const paragraph =
        emptyCheckout.querySelector(
          "p"
        );


      if (heading) {

        heading.textContent =
          "Your cart is empty";
      }


      if (paragraph) {

        paragraph.textContent =
          "Add products to your cart before continuing to checkout.";
      }


      const button =
        document.getElementById(
          "emptyShopButton"
        );


      if (button) {

        button.textContent =
          "Continue Shopping";


        button.onclick =
          () => {

            window.location.href =
              "index.html";
          };
      }
    }


    return;
  }


  if (emptyCheckout) {

    emptyCheckout.style.display =
      "none";
  }


  if (checkoutContent) {

    checkoutContent.style.display =
      "block";
  }


  await loadMarketHubSettings();


  if (
    !checkStoreAvailability()
  ) {

    return;
  }


  renderItems();

  calculateTotals();

  renderDeliveryInformation();

  loadSavedCheckout();
}

/* =========================================================
   START
========================================================= */

if (
  document.readyState ===
  "loading"
) {

  document.addEventListener(
    "DOMContentLoaded",
    () => {

      setupButtons();

      initCheckout();

    }
  );

} else {

  setupButtons();

  initCheckout();

}